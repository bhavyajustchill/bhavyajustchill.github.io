// Calculate the area of triangle.
#include<stdio.h>
#include<conio.h>
void main()
{
	int area,b,h;
	clrscr();
	printf("\n\tEnter the base: ");
	scanf("%d",&b);
	printf("\tEnter the height: ");
	scanf("%d",&h);
	area=(b*h)/2;
	printf("\n\tThe area of the triangle is %d",area);
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)