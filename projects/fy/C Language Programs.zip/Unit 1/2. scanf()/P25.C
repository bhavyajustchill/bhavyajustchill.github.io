#include<stdio.h>
#include<conio.h>
void main()
{
	int a=4,b=5,temp;
	clrscr();
	temp=a;
	a=b;
	b=temp;
	printf("a=%d",a);
	printf("b=%d",b);
	getch();

}
// Made by Bhavya Popat, B.Sc IT (D2)