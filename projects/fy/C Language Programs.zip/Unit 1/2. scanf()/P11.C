// Input A Rupee and print it's value converted into dollar.
#include<stdio.h>
#include<conio.h>
void main()
{
	int r,d;
	clrscr();
	printf("\n\tEnter the amount in INR: ");
	scanf("%d",&d);
	r=d/71;
	printf("\n\tThe amount of the entered Dollar value is %d",r);
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)