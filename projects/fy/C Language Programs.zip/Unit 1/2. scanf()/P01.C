// Enter the value of an integer variable and print it on screen.
#include<stdio.h>
#include<conio.h>
void main()
{
	int x;
	clrscr();
	printf("\n\n\t Enter an integer: ");
	scanf("%d",&x);
	printf("\t You Entered: %d",x);
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)