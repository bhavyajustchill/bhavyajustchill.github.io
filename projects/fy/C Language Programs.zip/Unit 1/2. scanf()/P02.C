// Input two numbers and print their addition.
#include<stdio.h>
#include<conio.h>
void main()
{
	int x,y,z;
	clrscr();
	printf("\n\n\tEnter First Value: ");
	scanf("%d",&x);
	printf("\tEnter Second Value: ");
	scanf("%d",&y);
	z=x+y;
	printf("\n\t%d + %d = %d",x,y,z);
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)