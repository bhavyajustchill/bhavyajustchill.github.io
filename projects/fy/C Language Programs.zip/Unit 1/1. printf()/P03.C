// Print your name & Address on screen.
#include<stdio.h>
#include<conio.h>
void main()
{
	clrscr();
	printf("\n\n\n\n\t\tBhavya B. Popat");
	printf("\n\n\t\tA-202, Panchnath Complex,\n\t\tOpp. Saint Mary's School,\n\t\tnear KKV Hall, Kalawad Road,\n\t\tRajkot - 360005.");
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)