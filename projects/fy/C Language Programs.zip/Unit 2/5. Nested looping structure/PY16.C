#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j=1;
	clrscr();
	for(i=1;i<=5;i++)
	{
		printf("%d",j);
		printf("\n");
		j=j*10;
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)