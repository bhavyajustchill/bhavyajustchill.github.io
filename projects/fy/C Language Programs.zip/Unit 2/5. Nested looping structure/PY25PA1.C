//Pyramid 25, Pattern 1
#include<stdio.h>
#include<conio.h>
void main()
{
	char i,k;
	clrscr();
	for(k=97;k<=101;k++)
	{
		for(i=k;i<=101;i++)
		{
			printf(" %c",i);
		}

		printf("\n");
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)