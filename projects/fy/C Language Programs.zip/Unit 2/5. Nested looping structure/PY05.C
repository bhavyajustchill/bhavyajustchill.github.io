// Pyramid 5, Pattern 1
#include<stdio.h>
#include<conio.h>
void main()
{
	char i;
	int j;
	clrscr();
	for(i='A';i<='E';i++)
	{
		for(j=1;j<=5;j++)
		{
			printf("%c",i);
		}
		printf("\n");
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)