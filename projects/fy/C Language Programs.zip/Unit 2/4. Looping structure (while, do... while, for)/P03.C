// Print 1, 3, 5, 7, 9.
#include<stdio.h>
#include<conio.h>
void main()
{
	int i;
	clrscr();
	for(i=1;i<=9;i+=2)
	{
		printf(" %d",i);
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)