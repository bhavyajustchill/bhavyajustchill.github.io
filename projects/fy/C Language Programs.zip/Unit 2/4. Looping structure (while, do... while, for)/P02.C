// Print 2, 4, 6, 8, 10.
#include<stdio.h>
#include<conio.h>
void main()
{
	int i;
	clrscr();
	for(i=2;i<=10;i+=2)
	{
		printf(" %d",i);
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)