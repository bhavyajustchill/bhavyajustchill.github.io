// Print 1, 10, 2, 9, 3, 8, 4, 7, 5, 6.
#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j=10;
	clrscr();
	for(i=1;i<=5;i++)
	{
		printf("%d %d ",i,j);
		j--;
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)