// Print the total of 1 to 50.
#include<stdio.h>
#include<conio.h>
void main()
{
	int i=1,sum=0;
	clrscr();
	while(i<=50)
	{
		sum=sum+i;
		i++;
	}
	printf("\n\tSum of 1 to 50 : %d",sum);
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)