// Print 10 to 1.
#include<stdio.h>
#include<conio.h>
void main()
{
	int i;
	clrscr();
	for(i=10;i>=1;i--)
	{
		printf("%d\n",i);
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)