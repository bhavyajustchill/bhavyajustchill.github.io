// Print first 100 odd numbers.
#include<stdio.h>
#include<conio.h>
void main()
{
	int i;
	clrscr();
	for(i=1;i<=199;i+=2)
	{
		printf(" %d",i);
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)