#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
	clrscr();
	printf("\n\tenter a : ");
	scanf("%d",&a);
	printf("\n\tenter b : ");
	scanf("%d",&b);
	a>b?printf("\n\n\tb is small"):printf("\n\n\ta is small");
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)