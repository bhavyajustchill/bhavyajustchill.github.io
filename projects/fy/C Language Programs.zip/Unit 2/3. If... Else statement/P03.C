#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
	clrscr();
	printf("\n\tenter the value of a : ");
	scanf("%d",&a);
	printf("\n\tenter the value of b : ");
	scanf("%d",&b);
	if(a>b)
	{
		printf("\n\n\tb is smaller than a");
	}
	else
	{
		printf("\n\n\ta is smaller than b");
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)