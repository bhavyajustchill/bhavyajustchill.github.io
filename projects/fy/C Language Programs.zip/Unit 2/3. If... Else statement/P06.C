#include<stdio.h>
#include<conio.h>
void main()
{
	int a;
	clrscr();
	printf("enter a : ");
	scanf("%d",&a);
	if (a%2)
	{
		printf("\n\n\ta is odd");
	}
	else
	{
		printf("\n\n\ta is even");
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)