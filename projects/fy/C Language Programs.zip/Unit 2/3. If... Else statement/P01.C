#include<stdio.h>
#include<conio.h>
void main()
{
	int x,y;
	clrscr();
	printf("Enter X : ");
	scanf("%d",&x);
	printf("Enter Y : ");
	scanf("%d",&y);
	if(x>y)
	{
		printf("\n\tX = %d",x);
	}
	else
	{
		printf("\n\tY = %d",y);
	}
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)