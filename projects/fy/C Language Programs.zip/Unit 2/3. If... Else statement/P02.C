#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b;
	clrscr();
	printf("Ente X : ");
	scanf("%d",&a);
	printf("Enter Y : ");
	scanf("%d",&b);
	a>b?printf("X : %d",a):printf("Y : %d",b);
	getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)