#include<stdio.h>
#include<conio.h>
#include<string.h>

void main()
{
 char m[20],e[20];
 clrscr();

 printf("Enter name :");
 scanf("%s",&m);

 strcpy(e,m);

 printf("\n%s",e);

 getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)