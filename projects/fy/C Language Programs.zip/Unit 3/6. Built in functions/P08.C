#include<stdio.h>
#include<conio.h>
#include<string.h>

void main()
{
 char m[20],e[20],r;
 clrscr();

 printf("Enter name :");
 scanf("%s",&m);

 strrev(m);
 printf("%s",m);
 getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)