#include<stdio.h>
#include<conio.h>
#include<math.h>

void main()
{
 double m,r;
 clrscr();

 printf("Enter No :");
 scanf("%lf",&m);

 r=log10(m);

 printf("\nLog = %.4lf",r);

 getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)