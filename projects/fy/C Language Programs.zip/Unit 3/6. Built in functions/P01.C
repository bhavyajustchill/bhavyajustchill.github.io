#include<stdio.h>
#include<conio.h>
#include<math.h>

void main()
{
 double m,e,r;
 clrscr();

 printf("Enter No :");
 scanf("%lf",&m);

 e=abs(m);

 printf("\nAbsolute Value:%.0lf",e);

 getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)