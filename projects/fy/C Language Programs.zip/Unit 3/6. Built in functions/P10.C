#include<stdio.h>
#include<conio.h>
#include<string.h>

void main()
{
 char m[20],e,r[20];
 clrscr();

 printf("Enter name :");
 scanf("%s",&m);

 strlwr(m);

 printf("\n%s",m);

 getch();
}
// Made by Bhavya Popat, B.Sc IT (D2)