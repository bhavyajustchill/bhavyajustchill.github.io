#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
struct node *head=NULL;
void enQueue(int);
void deQueue();
void display_Queue();
void main()
{
	int x,ch;
	while(1)
	{
		clrscr();
		printf("\n(1) Enqueue");
		printf("\n(2) Dequeue");
		printf("\n(3) Display Queue");
		printf("\n(4) Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
			printf("Enter a Value : ");
			scanf("%d",&x);
			enQueue(x);
			break;
			case 2:
			deQueue();
			break;
			case 3:
			display_Queue();
			break;
			case 4:
			printf("Thank You! Press any key to exit!");
			break;
			default:
			printf("Error! Enter a valid choice!");
			getch();
		}
		if(ch==4)
		break;
	}
	getch();
}
void enQueue(int x)
{
	struct node *temp,*temp1;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		temp1=head;
		while(temp1->next!=NULL)
		{
			temp1=temp1->next;
		}
		temp1->next=temp;
	}
}
void deQueue()
{
	struct node *temp=head;
	head=temp->next;
	free(temp);
}
void display_Queue()
{
	struct node *temp=head;
	if(head==NULL)
	{
		printf("Queue is Empty!");
	}
	else
	{
		printf("Displaying Queue : ");
		while(temp!=NULL)
		{
			printf("%d ",temp->data);
			temp=temp->next;
		}
	}
	getch();
}
// Made by Bhavya Popat