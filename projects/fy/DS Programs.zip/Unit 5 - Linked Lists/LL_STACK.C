#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
struct node *head=NULL;
void push(int);
void pop();
void peek();
void display();
void main()
{
	int x,ch;
	while(1)
	{
		clrscr();
		printf("\n(1) Push");
		printf("\n(2) Pop");
		printf("\n(3) Peek");
		printf("\n(4) Display");
		printf("\n(5) Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
			printf("Enter a value : ");
			scanf("%d",&x);
			push(x);
			break;
			case 2:
			pop();
			break;
			case 3:
			peek();
			break;
			case 4:
			display();
			break;
			case 5:
			printf("Thank You! Press any key to exit!");
			break;
			default:
			printf("Error! Enter a valid choice!");
			getch();
		}
		if(ch==5)
		break;
	}
	getch();
}
void push(int x)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	temp->next=head;
	head=temp;
}
void pop()
{
	struct node *temp=head;
	head=temp->next;
	free(temp);
}
void display()
{
	struct node *temp=head;
	if(head==NULL)
	{
		printf("Linked List is Empty!");
	}
	else
	{
		printf("Displaying Linked List : ");
		while(temp!=NULL)
		{
			printf("%d ",temp->data);
			temp=temp->next;
		}
	}
	getch();
}
void peek()
{
	struct node *temp=head;
	if(head==NULL)
	{
		printf("Stack Underflow!");
	}
	else
	{
		printf("Peek Element : %d",temp->data);
	}
	getch();
}
// Made by Bhavya Popat