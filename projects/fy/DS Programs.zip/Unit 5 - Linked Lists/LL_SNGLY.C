#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
struct node *head=NULL;
void searchNode(struct node *,int);
void insBegin(int);
void insMiddle(int,int);
void insLast(int);
void delBegin();
void delMiddle(int);
void delLast();
void recRev(struct node *);
void itrRev();
void bubbleSort(struct node *);
void countNodes();
void updateNode(int,int);
void display_linkList();
void main()
{
	int x,pos,ch,key;
	struct node *temp;
	while(1)
	{
		clrscr();
		printf("\n (1) Insert in Beginning");
		printf("\n (2) Insert in Middle");
		printf("\n (3) Insert in Last");
		printf("\n (4) Delete from Beginning");
		printf("\n (5) Delete from Middle");
		printf("\n (6) Delete from Last");
		printf("\n (7) Display Link List");
		printf("\n (8) Sort the data (With Bubble Sort)");
		printf("\n (9) Reverse (Recursive Method)");
		printf("\n(10) Reverse (Iterative Method)");
		printf("\n(11) Count Number of Nodes");
		printf("\n(12) Update a Node");
		printf("\n(13) Search a Node (Using Linear Search)");
		printf("\n(14) Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
			printf("Enter a value : ");
			scanf("%d",&x);
			insBegin(x);
			break;
			case 2:
			printf("Enter the Position : ");
			scanf("%d",&pos);
			printf("Enter a Value : ");
			scanf("%d",&x);
			insMiddle(x,pos);
			break;
			case 3:
			printf("Enter a value : ");
			scanf("%d",&x);
			insLast(x);
			break;
			case 4:
			delBegin();
			break;
			case 5:
			if(head==NULL)
			{
				printf("Linked List is Empty!");
				getch();
			}
			else
			{
				printf("Enter the Position : ");
				scanf("%d",&pos);
				delMiddle(pos);
			}
			break;
			case 6:
			delLast();
			break;
			case 7:
			display_linkList();
			break;
			case 8:
			bubbleSort(head);
			break;
			case 9:
			if(head==NULL)
			{
				printf("Linked List is Empty!");
				getch();
			}
			else
			{
				temp=head;
				printf("Link List Successfully Reversed!\n");
				printf("Displaying Link List : ");
				recRev(temp);
				getch();
			}
			break;
			case 10:
			if(head==NULL)
			{
				printf("Linked List is Empty!");
				getch();
			}
			else
			{
				itrRev();
			}
			break;
			case 11:
			countNodes();
			break;
			case 12:
			if(head==NULL)
			{
				printf("Linked List is Empty!");
				getch();
			}
			else
			{
				printf("Enter the Position : ");
				scanf("%d",&pos);
				printf("Enter Value : ");
				scanf("%d",&x);
				updateNode(x,pos);
			}
			break;
			case 13:
			if(head==NULL)
			{
				printf("Linked List is Empty!");
				getch();
			}
			else
			{
				printf("Enter the Key : ");
				scanf("%d",&key);
				searchNode(head,key);
			}
			break;
			case 14:
			printf("Thank You! Press any key to exit!");
			break;
			default:
			printf("Error! Please Enter a valid choice!");
			getch();
		}
		if(ch==14)
		{
			break;
		}
	}
	getch();
}
void searchNode(struct node *temp,int key)
{
	int pos=0,flag=0;
	while(temp->data!=NULL)
	{
		pos++;
		if(key==temp->data)
		{
			flag=1;
			break;
		}
		temp=temp->next;
	}
	if(flag==1)
	{
		printf("%d found at the Node %d",key,pos);
	}
	else if(flag==0)
	{
		printf("Entered Data doesn't exist!");
	}
	getch();
}
void bubbleSort(struct node *temp)
{
       int swap,flag;
       struct node *temp1,*temp2=NULL;
       if(temp==NULL)
       {
		printf("Linked List is Empty!");
		getch();
		return;
       }
       do
       {
		flag=0;
		temp1=temp;
		while(temp1->next!=temp2)
		{
			if(temp1->data > temp1->next->data)
			{
				swap=temp1->next->data;
				temp1->next->data=temp1->data;
				temp1->data=swap;
			}
			flag=1;
			temp1=temp1->next;
		}
		temp2=temp1;
       }
       while(flag);
       printf("Data Successfully Sorted!\n");
       display_linkList();
}
void delMiddle(int pos)
{
	int i;
	struct node *temp=head,*temp1;
	if(pos==1)
	{
		head=temp->next;
		free(temp);
		return;
	}
	temp1=temp;
	temp=temp->next;
	for(i=0;i<pos-2;i++)
	{
	       temp1=temp;
	       temp=temp->next;
	}
	if(temp->data==NULL)
	{
		printf("Entered Position is Invalid!");
		getch();
	}
	temp1->next=temp->next;
	free(temp);
}
void insMiddle(int x,int pos)
{
	int i;
	struct node *temp,*temp1;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	if(pos==1)
	{
		temp->next=head;
		head=temp;
		return;
	}
	temp1=head;
	for(i=0;i<pos-2;i++)
	{
		temp1=temp1->next;
	}
	temp->next=temp1->next;
	temp1->next=temp;
}
void insBegin(int x)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	temp->next=head;
	head=temp;
}
void delBegin()
{
	struct node *temp=head;
	if(head==NULL)
	{
		printf("Linked List is Empty!");
		getch();
	}
	else
	{
		head=temp->next;
		free(temp);
	}
}
void display_linkList()
{
	struct node *temp=head;
	if(head==NULL)
	{
		printf("Linked List is Empty!");
	}
	else
	{
		printf("Displaying Linked List : ");
		while(temp!=NULL)
		{
			printf("%d ",temp->data);
			temp=temp->next;
		}
	}
	getch();
}
void insLast(int x)
{
	struct node *temp,*temp1;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		temp1=head;
		while(temp1->next!=NULL)
		{
			temp1=temp1->next;
		}
		temp1->next=temp;
	}
}
void delLast()
{
	struct node *temp=head,*prev=NULL;
	if(head==NULL)
	{
		printf("Linked List is Empty!");
		getch();
	}
	else
	{
		if(head->next==NULL)
		{
			head=NULL;
			free(temp);
		}
		prev=temp;
		temp=temp->next;
		while(temp->next!=NULL)
		{
			prev=temp;
			temp=temp->next;
		}
		prev->next=NULL;
		free(temp);
	}
}
void recRev(struct node *temp)
{
	if(temp==NULL)
	{
		return;
	}
	recRev(temp->next);
	printf("%d ",temp->data);
}
void itrRev()
{
	struct node *temp=head,*prev,*temp1;
	prev=NULL;
	while(temp!=NULL)
	{
		temp1=temp->next;
		temp->next=prev;
		prev=temp;
		temp=temp1;
	}
	head=prev;
	printf("Linked List Successfully Reversed!\n");
	display_linkList();
}
void countNodes()
{
	struct node *temp=head;
	int count=0;
	while(temp!=NULL)
	{
		temp=temp->next;
		count++;
	}
	if(count==0)
	{
		printf("Linked List is Empty!");
	}
	else
	{
		printf("No. of Nodes : %d",count);
	}
	getch();
}
void updateNode(int x,int pos)
{
	int i;
	struct node *temp=head,*temp1,*temp2;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=x;
	temp->next=NULL;
	temp1=head;
	if(pos!=1)
	{
		temp1=temp1->next;
	}
	for(i=0;i<pos-2;i++)
	{
		temp1=temp1->next;
	}
	temp1->data=x;
}