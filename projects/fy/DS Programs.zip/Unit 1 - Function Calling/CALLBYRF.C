#include<stdio.h>
#include<conio.h>
void swapVal(int*,int*);
void main()
{
	int a,b;
	clrscr();
	printf("Enter A : ");
	scanf("%d",&a);
	printf("Enter B : ");
	scanf("%d",&b);
	swapVal(&a,&b);
	printf("\nA : %d\nB : %d",a,b);
	getch();
}
void swapVal(int *x,int *y)
{
	int temp;
	temp=*x;
	*x=*y;
	*y=temp;
	printf("\nX : %u\nY : %u\n",x,y);
}
// Made by Bhavya Popat