#include<stdio.h>
#include<conio.h>
#define size 10
int top=-1;
int a[size];
void push();
void pop();
void peek();
void display();
void main()
{
	int ch;
	while(1)
	{
		clrscr();
		printf("\n(1) Push");
		printf("\n(2) Pop");
		printf("\n(3) Peek");
		printf("\n(4) Display");
		printf("\n(5) Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
			push();
			break;
			case 2:
			pop();
			break;
			case 3:
			peek();
			break;
			case 4:
			display();
			break;
			case 5:
			printf("Thank You! Press any key to exit!");
			break;
			default:
			printf("Error! Enter a valid choice!");
			getch();
		}
		if(ch==5)
		break;
	}
	getch();
}
void push()
{
	int x;
	if(top==size-1)
	{
		printf("Stack Overflow!");
		getch();
	}
	else
	{
		printf("Enter a value to Push : ");
		scanf("%d",&x);
		top=top+1;
		a[top]=x;
	}
}
void pop()
{
	if(top==-1)
	{
		printf("Stack Underflow!");
		getch();
	}
	else
	top=top-1;
}
void peek()
{
	printf("Peek Element : %d",a[top]);
	getch();
}
void display()
{
	int i;
	if(top==-1)
	{
		printf("Stack Underflow!");
		getch();
	}
	else
	{
		printf("Displaying Stack : ");
		for(i=top;i>=0;i--)
		printf("%d ",a[i]);
	}
	getch();
}
// Made by Bhavya Popat