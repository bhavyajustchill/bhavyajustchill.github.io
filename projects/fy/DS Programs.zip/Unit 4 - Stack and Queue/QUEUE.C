#include<stdio.h>
#include<conio.h>
#define size 10
int rear=-1,front=-1;
int a[size];
void enQueue();
void deQueue();
void displayQueue();
void main()
{
	int ch;
	while(1)
	{
		clrscr();
		printf("\n(1) Enqueue");
		printf("\n(2) Dequeue");
		printf("\n(3) Display");
		printf("\n(4) Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
			enQueue();
			break;
			case 2:
			deQueue();
			break;
			case 3:
			displayQueue();
			break;
			case 4:
			printf("Thank You! Press any key to exit!");
			break;
			default:
			printf("Error! Enter a valid choice!");
			getch();
		}
		if(ch==4)
		break;
	}
	getch();
}
void enQueue()
{
	int x;
	if(rear==size-1)
	{
		printf("\nQueue is Full!\n");
		getch();
		return;
	}
	else if(front==-1 && rear==-1)
	{
		front=0;
		rear=0;
		printf("Enter a value : ");
		scanf("%d",&x);
	}
	else
	{
		rear=rear+1;
		printf("Enter a value : ");
		scanf("%d",&x);
	}
	a[rear]=x;
}
void deQueue()
{
	if(front==-1 && rear==-1)
	{
		printf("Queue is Empty!");
		getch();
		return;
	}
	else if(front==rear)
	{
		front=-1;
		rear=-1;
	}
	else
	{
		front=front+1;
	}
}
void displayQueue()
{
	int i;
	if(front==-1 && rear==-1)
	{
		printf("Queue is Empty!");
		getch();
		return;
	}
	else
	{
		printf("Displaying Queue : ");
		for(i=front;i<=rear;i++)
		{
			printf("%d ",a[i]);
		}
	}
	getch();
}
// Made by Bhavya Popat