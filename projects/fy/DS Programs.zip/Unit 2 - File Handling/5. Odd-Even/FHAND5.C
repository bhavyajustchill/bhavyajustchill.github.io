#include<stdio.h>
#include<conio.h>
void main()
{
	FILE *fp,*fpo,*fpe;
	int i=1;
	clrscr();
	fp=fopen("digits.txt","w");
	fpo=fopen("odd.txt","w");
	fpe=fopen("even.txt","w");
	for(i=1;i<=9;i++)
	{
		putw(i,fp);
	}
	putw(EOF,fp);
	fclose(fp);
	fp=fopen("digits.txt","r");
	while((i=getw(fp))!=EOF)
	{
		if(i%2==0)
		{
			putw(i,fpe);
		}
		else
		{
			putw(i,fpo);
		}
	}
	fclose(fp);
	fclose(fpe);
	fclose(fpo);
	fp=fopen("digits.txt","r");
	while((i=getw(fp))!=EOF)
	{
		printf("%d ",i);
	}
	printf("\n");
	fpe=fopen("even.txt","r");
	while((i=getw(fpe))!=EOF)
	{
		printf("%d ",i);
	}
	printf("\n");
	fpo=fopen("odd.txt","r");
	while((i=getw(fpo))!=EOF)
	{
		printf("%d ",i);
	}
	getch();
}