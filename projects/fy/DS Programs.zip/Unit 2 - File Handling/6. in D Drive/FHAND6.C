#include<stdio.h>
#include<conio.h>
void main()
{
	FILE *fp;
	int x;
	clrscr();
	fp=fopen("d:\
	bhavya.txt","w");
	printf("Enter Number : ");
	scanf("%d",&x);
	fprintf(fp,"%d",x);
	fclose(fp);
	getch();
}