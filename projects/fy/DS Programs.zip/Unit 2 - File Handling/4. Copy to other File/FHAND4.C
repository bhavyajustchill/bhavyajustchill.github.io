#include<stdio.h>
#include<conio.h>
void main()
{
	FILE *fp,*fp1;
	char c;
	clrscr();
	fp=fopen("bhavya.txt","r");
	fp1=fopen("popat.txt","w");
	while((c=getc(fp))!=EOF)
	{
		putc(c,fp1);
	}
	fclose(fp);
	fclose(fp1);
	getch();
}