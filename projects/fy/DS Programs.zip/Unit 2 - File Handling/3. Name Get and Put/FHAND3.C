#include<stdio.h>
#include<conio.h>
void main()
{
	FILE *fp;
	char c;
	clrscr();
	fp=fopen("bhavya.txt","w");
	printf("Type Something:\n");
	while((c=getchar())!=EOF)
	{
		putc(c,fp);
	}
	fclose(fp);
	fopen("bhavya.txt","r");
	printf("\nYou Typed :\n");
	while((c=getc(fp))!=EOF)
	{
		printf("%c",c);
	}
	fclose(fp);
	getch();
}