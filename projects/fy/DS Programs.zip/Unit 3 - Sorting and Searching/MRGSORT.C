#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void merge(int*,int);
void mergeSort(int*,int,int,int*,int*);
void main()
{
	int *p,n,i;
	clrscr();
	printf("Enter Number of Elements : ");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("Enter %d elements : ",n);
	for(i=0;i<n;i++)
	scanf("%d",&p[i]);
	merge(p,n);
	printf("After Merge Sorting..\n");
	for(i=0;i<n;i++)
	printf("%d ",p[i]);
	free(p);
	getch();
}
void merge(int *p,int n)
{
	int *left,mid,*right,i;
	if(n<2)
	return;
	mid=n/2;
	left=(int*)malloc(mid*sizeof(int));
	right=(int*)malloc((n-mid)*sizeof(int));
	for(i=0;i<mid;i++)
	left[i]=p[i];
	for(i=mid;i<n;i++)
	right[i-mid]=p[i];
	merge(left,mid);
	merge(right,n-mid);
	mergeSort(p,mid,n-mid,right,left);
}
void mergeSort(int *p,int m,int nm,int *r,int *l)
{
	int i=0,j=0,k=0;
	for(;i<m&&j<nm;)
	if(l[i]<r[j])
	p[k++]=l[i++];
	else
	p[k++]=r[j++];
	while(i<m)
	p[k++]=l[i++];
	while(j<nm)
	p[k++]=r[j++];
}
// Made by Bhavya Popat