#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],n,key,i;
	clrscr();
	printf("Enter number of elements : ");
	scanf("%d",&n);
	printf("Enter %d elements : ",n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("Enter the Key : ");
	scanf("%d",&key);
	for(i=0;i<n;i++)
	{
		if(a[i]==key)
		{
			printf("%d found at location a[%d]!",key,i);
			break;
		}
	}
	getch();
}
// Made by Bhavya Popat