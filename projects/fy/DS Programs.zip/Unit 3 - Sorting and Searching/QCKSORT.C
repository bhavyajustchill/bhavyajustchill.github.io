#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int partition(int*,int,int);
void quickSort(int*,int,int);
void main()
{
	int *p,i,n;
	clrscr();
	printf("Enter Number of Elements : ");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("Enter %d elements : ",n);
	for(i=0;i<n;i++)
	scanf("%d",&p[i]);
	quickSort(p,0,n-1);
	printf("After Quick Sorting..\n");
	for(i=0;i<n;i++)
	printf("%d ",p[i]);
	free(p);
	getch();
}
void quickSort(int *a,int start,int end)
{
	int pi;
	if(start<end)
	{
		pi=partition(a,start,end);
		quickSort(a,start,pi-1);
		quickSort(a,pi+1,end);
	}
}
int partition(int *a,int start,int end)
{
	int pivot,i,temp;
	pivot=a[end];
	for(i=start;i<=end-1;i++)
	{
		if(a[i]<pivot)
		{
			temp=a[start];
			a[start]=a[i];
			a[i]=temp;
			start=start+1;
		}
	}
	temp=a[start];
	a[start]=a[end];
	a[end]=temp;
	return start;
}
// Made by Bhavya Popat