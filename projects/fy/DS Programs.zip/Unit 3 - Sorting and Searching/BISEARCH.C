#include<stdio.h>
#include<conio.h>
void main()
{
	int a[100],n,key,start,mid,end,i;
	clrscr();
	printf("Enter number of elements : ");
	scanf("%d",&n);
	printf("[WARNING: Data must be sorted!]\n");
	printf("Enter %d elements : ",n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	start=0;
	end=n;
	printf("Enter Key : ");
	scanf("%d",&key);
	while(start<=end)
	{
		mid=(start+end)/2;
		if(key>a[mid])
		start=mid+1;
		else if(key<a[mid])
		end=mid-1;
		else if(key==a[mid])
		{
			printf("%d found at location a[%d]!",key,mid);
			break;
		}
	}
	getch();
}
// Made by Bhavya Popat