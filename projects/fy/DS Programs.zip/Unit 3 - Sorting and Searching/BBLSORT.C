#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void bubbleSort(int*,int);
void main()
{
	int n,i,*p;
	clrscr();
	printf("Enter number of elements : ");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("Enter %d elements : ",n);
	for(i=0;i<n;i++)
	scanf("%d",&p[i]);
	bubbleSort(p,n);
	printf("After Bubble Sorting..\n");
	for(i=0;i<n;i++)
	printf("%d ",p[i]);
	free(p);
	getch();
}
void bubbleSort(int *a,int n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
	for(j=0;j<n-i-1;j++)
	if(a[j]>a[j+1])
	{
		temp=a[j];
		a[j]=a[j+1];
		a[j+1]=temp;
	}
}
// Made by Bhavya Popat