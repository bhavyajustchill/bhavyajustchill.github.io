#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void selectionSort(int*,int);
void main()
{
	int n,i,*p;
	clrscr();
	printf("Enter number of elements : ");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("\nEnter %d elements : ",n);
	for(i=0;i<n;i++)
	scanf("%d",&p[i]);
	selectionSort(p,n);
	printf("After Selection Sorting..\n");
	for(i=0;i<n;i++)
	printf("%d ",p[i]);
	free(p);
	getch();
}
void selectionSort(int *a,int n)
{
	int i,j,min,temp;
	for(i=0;i<n-1;i++)
	{
		min=i;
		for(j=i+1;j<n;j++)
		if(a[j]<a[min])
		min=j;
		temp=a[min];
		a[min]=a[i];
		a[i]=temp;
	}
}
// Made by Bhavya Popat