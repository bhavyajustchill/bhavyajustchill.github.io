#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void insertionSort(int*,int);
void main()
{
	int *p,i,n;
	clrscr();
	printf("Enter number of elements : ");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("Enter %d Elements : ",n);
	for(i=0;i<n;i++)
	scanf("%d",&p[i]);
	insertionSort(p,n);
	printf("After Insertion Sorting..\n");
	for(i=0;i<n;i++)
	printf("%d ",p[i]);
	free(p);
	getch();
}
void insertionSort(int *a,int n)
{
	int i,space,temp;
	for(i=1;i<n;i++)
	{
		temp=a[i];
		space=i;
		while(space>0 && a[space-1]>temp)
		a[space--]=a[space-1];
		a[space]=temp;
	}
}
// Made by Bhavya Popat