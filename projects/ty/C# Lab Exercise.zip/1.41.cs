﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Program41
{
    public static void Main()
    {
        int[] nums = { 1, 2, 2, 3, 3, 4, 5, 6, 5, 7, 7, 7, 8, 8, 1 };
        int[] nums1 = { 1, 2, 2, 3, 3, 4, 5, 6, 5, 7, 7, 7, 8, 8, 5 };
        Console.WriteLine("Array1: [{0}]", string.Join(", ", nums));
        Console.WriteLine("Array2: [{0}]", string.Join(", ", nums1));
        Console.WriteLine((nums[0].Equals(nums1[0])) || (nums[nums.Length - 1].Equals(nums1[nums1.Length - 1])));
    }
}