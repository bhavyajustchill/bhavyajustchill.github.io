﻿// Made by Bhavya Popat
using System;
public class Program22
{
    public static void Main()
    {
        Console.WriteLine("Enter a String: ");
        string line = Console.ReadLine();
        Console.WriteLine(line.ToLower());
    }
}