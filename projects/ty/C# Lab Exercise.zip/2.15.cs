﻿// Made by Bhavya Popat
using System;
public class Program15
{
    public static void Main()
    {
        int m, n;
        Console.Write("The value of m : ");
        m = Convert.ToInt32(Console.ReadLine());
        if (m != 0)
            if (m > 0)
                n = 1;
            else
                n = -1;
        else
            n = 0;
        Console.WriteLine("The value of n = {0}", n);
    }
}