﻿// Made by Bhavya Popat
using System;
public class Program12
{
    public static void Main()
    {
        int num;
        Console.Write("Input an integer : ");
        num = Convert.ToInt32(Console.ReadLine());
        if (num >= 0)
            Console.WriteLine("{0} is a positive number", num);
        else
            Console.WriteLine("{0} is a negative number", num);
    }
}