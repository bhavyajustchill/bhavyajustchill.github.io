﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
public class Program21
{
    public static void Main()
    {
        Console.WriteLine("Input an integer:");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(result_twentyOf100Or200(x));
    }

    public static bool result_twentyOf100Or200(int n)
    {
        if (Math.Abs(n - 100) <= 20 || Math.Abs(n - 200) <= 20)
            return true;
        else
            return false;
    }
}