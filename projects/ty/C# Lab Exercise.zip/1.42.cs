﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Program42
{
    public static void Main()
    {
        int[] nums = { 1, 2, 8 };
        Console.WriteLine("Array1: [{0}]", string.Join(", ", nums));
        var temp = nums[0];
        for (var i = 0; i < nums.Length - 1; i++)
        {
            nums[i] = nums[i + 1];
        }
        nums[nums.Length - 1] = temp;
        Console.WriteLine("After rotating array becomes: [{0}]", string.Join(", ", nums));
    }
}