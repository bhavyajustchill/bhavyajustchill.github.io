﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program30
{
    public static void Main()
    {
        int monno;
        Console.Write("Input Month No : ");
        monno = Convert.ToInt32(Console.ReadLine());
        switch (monno)
        {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                Console.WriteLine("Month has 31 days.");
                break;
            case 2:
                Console.Write("The 2nd month is a February and it usually has 28 days. ");
                Console.WriteLine("But in leap year, it has 29 days.");
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                Console.WriteLine("Month has 30 days.");
                break;
            default:
                Console.WriteLine("Invalid Month Number!");
                break;
        }
    }
}