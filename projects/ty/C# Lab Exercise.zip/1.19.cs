﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
public class Program19
{
    public static void Main()
    {
        int a, b;
        Console.Write("Enter first number : ");
        a = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter second number : ");
        b = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(result_abs(a, b));
    }
    public static int result_abs(int x, int y)
    {
        if (x > y)
        {
            return (x - y) * 2;
        }
        return y - x;
    }
}