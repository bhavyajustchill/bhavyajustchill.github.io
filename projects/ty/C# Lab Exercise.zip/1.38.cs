﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Program38
{
    public static void Main()
    {
        int[] nums = { 1, 2, 2, 3, 3, 4, 5, 6, 5, 7, 7, 7, 8, 8, 9 };
        Console.WriteLine("Given Array: [{0}]", string.Join(", ", nums));
        Console.Write("Input an integer: ");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Number of " + x + " present in the said array: " + nums.Count(n => n == x));
    }
}