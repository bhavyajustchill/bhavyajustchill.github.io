﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program20
{
    public static void Main()
    {
        int tmp;

        Console.Write("Input days temperature : ");
        tmp = Convert.ToInt32(Console.ReadLine());
        if (tmp < 0)
            Console.WriteLine("Freezing weather.");
        else if (tmp < 10)
            Console.WriteLine("Very cold weather.");
        else if (tmp < 20)
            Console.WriteLine("Cold weather.");
        else if (tmp < 30)
            Console.WriteLine("Normal in temp.");
        else if (tmp < 40)
            Console.WriteLine("Its Hot.");
        else
            Console.WriteLine("Its very hot.");
    }
}