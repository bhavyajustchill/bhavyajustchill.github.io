﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program50
{
    public static void Main()
    {
        int i, j, n;
        int[,] arr1 = new int[50, 50];
        int[,] brr1 = new int[50, 50];
        int[,] crr1 = new int[50, 50];

        Console.Write("Input the size of the square matrix (less than 5): ");
        n = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input elements in the first matrix :\n");
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                Console.Write("element - [{0},{1}] : ", i, j);
                arr1[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        Console.Write("Input elements in the second matrix :\n");
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                Console.Write("element - [{0},{1}] : ", i, j);
                brr1[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }
        Console.Write("\nThe First matrix is :\n");
        for (i = 0; i < n; i++)
        {
            Console.Write("\n");
            for (j = 0; j < n; j++)
                Console.Write("{0}  ", arr1[i, j]);
        }

        Console.Write("\nThe Second matrix is :\n");
        for (i = 0; i < n; i++)
        {
            Console.Write("\n");
            for (j = 0; j < n; j++)
                Console.Write("{0}  ", brr1[i, j]);
        }

        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++)
                crr1[i, j] = arr1[i, j] + brr1[i, j];
        Console.Write("\nThe Addition of two matrix is : \n");
        for (i = 0; i < n; i++)
        {
            Console.Write("\n");
            for (j = 0; j < n; j++)
                Console.Write("{0}  ", crr1[i, j]);
        }
        Console.WriteLine();
    }
}