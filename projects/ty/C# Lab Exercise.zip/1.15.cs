﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
public class Program15
{
    public static void Main()
    {
        Console.WriteLine("Atmiya University");
        Console.WriteLine(remove_char("Atmiya University", 2));
        Console.WriteLine(remove_char("Atmiya University", 7));
    }
    public static string remove_char(string str, int n)
    {
        return str.Remove(n, 1);
    }
}