﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Program30
{
    public static void Main()
    {
        string str;
        Console.Write("Input a string : ");
        str = Console.ReadLine();
        if (str.Length >= 4)
        {
            Console.WriteLine(str.Substring(str.Length - 4) + str.Substring(str.Length - 4) + str.Substring(str.Length - 4) + str.Substring(str.Length - 4));
        }
        else
        {
            Console.WriteLine(str + str + str + str);
        }
    }
}