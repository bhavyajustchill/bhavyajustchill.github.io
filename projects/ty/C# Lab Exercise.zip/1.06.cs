﻿// Made by Bhavya Popat
using System;
public class Program6
{
    public static void Main()
    {
        int n1, n2, n3, prod;
        Console.Write("Input the first number to multiply: ");
        n1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input the second number to multiply: ");
        n2 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input the third number to multiply: ");
        n3 = Convert.ToInt32(Console.ReadLine());
        prod = n1 * n2 * n3;
        Console.WriteLine("Output: {0} x {1} x {2} = {3}", n1, n2, n3, prod);
    }
}