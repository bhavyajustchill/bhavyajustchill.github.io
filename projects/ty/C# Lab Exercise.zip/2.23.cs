﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program23
{
    public static void Main()
    {
        char ch;
        Console.Write("Input an Alphabet (A-Z or a-z) : ");
        ch = Convert.ToChar(Console.ReadLine().ToLower());
        int i = ch;
        if (i >= 48 && i <= 57)
        {
            Console.Write("You entered a number, Please enter an alpahbet.");
        }
        else
        {
            switch (ch)
            {
                case 'a':   case 'e':
                case 'i':   case 'o':
                case 'u':
                    Console.WriteLine("The Alphabet is vowel");
                    break;
                case '@':   case '#':
                case '$':   case '%':
                case '&':   case '_':
                case '+':   case '-':
                case '*':   case '/':
                    Console.WriteLine("You entered a special symbol, Please enter an alphabet.");
                    break;
                default:
                    Console.WriteLine("The Alphabet is consonant");
                    break;
            }
        }
    }
}