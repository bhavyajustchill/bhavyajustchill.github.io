﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program19
{
    public static void Main()
    {
        double rl, phy, che, ca, total;
        double per;
        string nm, div;

        Console.Write("Input the Roll Number of the student :");
        rl = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input the Name of the Student :");
        nm = Console.ReadLine();

        Console.Write("Input the marks of Physics, Chemistry and Computer Application : ");
        string mks = Console.ReadLine();
        string[] tokens = mks.Split(' ');
        phy = int.Parse(tokens[0]);
        che = int.Parse(tokens[1]);
        ca = int.Parse(tokens[2]);
        Console.WriteLine();

        total = phy + che + ca;
        per = total / 3.0;
        if (per >= 60)
            div = "First";
        else
            if (per < 60 && per >= 50)
                div = "Second";
            else
                if (per < 50 && per >= 40)
                    div = "Pass";
                else
                    div = "Fail";

        Console.WriteLine("Roll No : {0}", rl);
        Console.WriteLine("Name of Student : {0}", nm);
        Console.WriteLine("Marks in Physics : {0}", phy);
        Console.WriteLine("Marks in Chemistry : {0}", che);
        Console.WriteLine("Marks in Computer Application : {0}", ca);
        Console.WriteLine("Total Marks = {0}", total);
        Console.WriteLine("Percentage = {0}", per);
        Console.WriteLine("Division = {0}", div);
    }
}