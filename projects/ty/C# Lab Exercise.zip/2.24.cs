﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program24
{
    public static void Main()
    {
        int cprice, sprice, plamt;

        Console.Write("Input Cost Price: ");
        cprice = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input Selling Price: ");
        sprice = Convert.ToInt32(Console.ReadLine());

        if (sprice > cprice)
        {
            plamt = sprice - cprice;
            Console.WriteLine("You can book your profit amount : {0}", plamt);
        }
        else if (cprice > sprice)
        {
            plamt = cprice - sprice;
            Console.WriteLine("You got a loss of amount : {0}", plamt);
        }
        else
        {
            Console.WriteLine("You have niether gained profit nor suffered loss.");
        }  
    }
}