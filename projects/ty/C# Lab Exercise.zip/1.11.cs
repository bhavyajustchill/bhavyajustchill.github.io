﻿// Made by Bhavya Popat
using System;
public class Program11
{
    public static void Main()
    {
        int age;
        Console.Write("Enter your age - ");
        age = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("You look older than {0} ", age);
    }
}