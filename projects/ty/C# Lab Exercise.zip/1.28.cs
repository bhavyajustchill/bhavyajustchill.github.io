﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
public class Program28
{
    public static void Main()
    {
        Console.Write("Hexadecimal number: ");
        string hexValue = Console.ReadLine();
        hexValue = hexValue.ToUpper();
        int decValue = int.Parse(hexValue, System.Globalization.NumberStyles.HexNumber);
        Console.WriteLine("Convert to-");
        Console.WriteLine("Decimal number: " + decValue);
    }
}