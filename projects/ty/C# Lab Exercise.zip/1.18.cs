﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
public class Program18
{
    public static void Main()
    {
        int a, b;
        Console.Write("Enter first number : ");
        a = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter second number : ");
        b = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(SumTriple(a, b));
    }
    public static int SumTriple(int x, int y)
    {
        return x == y ? (x + y) * 3 : x + y;
    }
}