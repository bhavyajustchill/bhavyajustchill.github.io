﻿// Made by Bhavya Popat
using System;
public class Program8
{
    public static void Main()
    {
        int n1, n2;
        bool bothEven;
        Console.Write("Input First number: ");
        n1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input Second number: ");
        n2 = Convert.ToInt32(Console.ReadLine());

        bothEven = ((n1 % 2 == 0)
            && (n2 % 2 == 0)) ? true : false;

        Console.WriteLine(bothEven ?
          "Both are Even Numbers" :
          "Both aren't Even Numbers");
    }
}