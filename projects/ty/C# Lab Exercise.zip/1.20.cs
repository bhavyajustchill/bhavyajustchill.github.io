﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
public class Program20
{
    public static void Main()
    {
        int a, b, sum;
        bool flag;
        Console.Write("Enter first number : ");
        a = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter second number : ");
        b = Convert.ToInt32(Console.ReadLine());
        sum = a + b;
        if (a == 20 || b == 20 || sum == 20)
        {
            flag = true;
            Console.WriteLine(flag);
        }
        else
        {
            flag = false;
            Console.WriteLine(flag);
        }
    }
}