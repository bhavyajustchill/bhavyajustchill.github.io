﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program31
{
    public static void Main()
    {
        int num1, num2, opt;

        Console.Write("Enter the first Integer :");
        num1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter the second Integer :");
        num2 = Convert.ToInt32(Console.ReadLine());


        Console.WriteLine("\nHere are the options :");
        Console.WriteLine("1-Addition.\n2-Substraction.\n3-Multiplication.\n4-Division.\n5-Exit.");
        Console.Write("\nInput your choice :");
        opt = Convert.ToInt32(Console.ReadLine());

        switch (opt)
        {
            case 1:
                Console.WriteLine("The Addition of  {0} and {1} is: {2}", num1, num2, num1 + num2);
                break;

            case 2:
                Console.WriteLine("The Substraction of {0}  and {1} is: {2}", num1, num2, num1 - num2);
                break;

            case 3:
                Console.WriteLine("The Multiplication of {0}  and {1} is: {2}", num1, num2, num1 * num2);
                break;

            case 4:
                if (num2 == 0)
                {
                    Console.WriteLine("The second integer is zero. Devide by zero.");
                }
                else
                {
                    Console.WriteLine("The Division of {0}  and {1} is : {2}", num1, num2, num1 / num2);
                }
                break;

            case 5:
                break;

            default:
                Console.Write("Inorrect option!");
                break;
        }
    }
}