﻿// Made by Bhavya Popat
using System;
public class Program2
{
    public static void Main()
    {
        Console.Write("Enter first number : ");
        int a = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter second number : ");
        int b = Convert.ToInt32(Console.ReadLine());
        int c = a + b;
        Console.WriteLine("Sum : " + c);
    }
}