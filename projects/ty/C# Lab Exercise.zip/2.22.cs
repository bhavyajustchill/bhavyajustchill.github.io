﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program22
{
    public static void Main()
    {
        int anga, angb, angc, sum;

        Console.Write("Input angle 1 of triangle: ");
        anga = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input angle 2 of triangle: ");
        angb = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input angle 3 of triangle: ");
        angc = Convert.ToInt32(Console.ReadLine());

        sum = anga + angb + angc;

        if (sum == 180)
        {
            Console.WriteLine("The triangle is valid.");
        }
        else
        {
            Console.WriteLine("The triangle is not valid.");
        }  
    }
}