﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.IO;
public class Program27
{
    public static void Main()
    {
        FileInfo f = new FileInfo(@"E:/C# Lab Exercise/fileSizeDemo/test.txt");		// needs full path to file
        Console.WriteLine("Size of a file: " + f.Length.ToString());
    }
}