﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Program21
{
    public static void Main()
    {
        int sidea, sideb, sidec;

        Console.Write("Input side 1 of triangle: ");
        sidea = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input side 2 of triangle: ");
        sideb = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input side 3 of triangle: ");
        sidec = Convert.ToInt32(Console.ReadLine());

        if (sidea == sideb && sideb == sidec)
        {
            Console.WriteLine("This is an equilateral triangle.");
        }
        else if (sidea == sideb || sidea == sidec || sideb == sidec)
        {
            Console.WriteLine("This is an isosceles triangle.");
        }
        else
        {
            Console.WriteLine("This is a scalene triangle.");
        }  
    }
}