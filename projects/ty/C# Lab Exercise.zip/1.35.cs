﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Program35
{
    public static void Main()
    {
        string str = "PHP Tutorial";
        Console.WriteLine("Original String: " + str);
        Console.WriteLine("\nAfter Removal of 'HP' from the String: "+(str.Substring(1, 2).Equals("HP") ? str.Remove(1, 2) : str));
        Console.WriteLine();
    }
}