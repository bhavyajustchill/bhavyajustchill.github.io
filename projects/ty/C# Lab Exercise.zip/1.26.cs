﻿// Made by Bhavya Popat
using System;
using System.Collections.Generic;
public class Program26
{
    public static void Main()
    {
        Console.WriteLine("Enter a String:");
        string line = Console.ReadLine();
        Console.WriteLine("Original String: " + line);
        string result = "";
        List<string> wordsList = new List<string>();
        string[] words = line.Split(new[] {" "}, StringSplitOptions.None);
        for (int i = words.Length - 1; i >= 0; i--)
        {
            result += words[i] + " ";
        }
        wordsList.Add(result);
        foreach (String s in wordsList)
        {

            Console.WriteLine("Reverse String: " + s);
        }
    }
}