﻿// Made by Bhavya Popat
using System;
public class Program14
{
    public static void Main()
    {
        int vote_age;
        Console.Write("Enter the age of the candidate : ");
        vote_age = Convert.ToInt32(Console.ReadLine());
        if (vote_age < 18)
            Console.WriteLine("Sorry! You are not eligible for casting your vote.");
        else
            Console.WriteLine("Congratulation! You are eligible for casting your vote.");
    }
}