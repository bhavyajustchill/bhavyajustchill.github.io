﻿// Made by Bhavya Popat
using System;
public class Program3
{
    public static void Main()
    {
        Console.Write("Enter first number : ");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.Write("Enter second number : ");
        double b = Convert.ToDouble(Console.ReadLine());
        double c = a / b;
        Console.WriteLine("Division : " + c);
    }
}