﻿// Made by Bhavya Popat
using System;
public class Program18
{
    public static void Main()
    {
        int p, c, m;

        Console.WriteLine("Eligibility Criteria :");
        Console.WriteLine("Marks in Maths >= 65");
        Console.WriteLine("Marks in Phy >= 55");
        Console.WriteLine("Marks in Chem >= 50");
        Console.Write("Total in all three subject >= 180 ");
        Console.WriteLine("  OR   Total in Maths and Physics >= 140");
        Console.WriteLine("\n--------------------------------------------------------------------------\n");


        Console.Write("Input the marks obtained in Physics :");
        p = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input the marks obtained in Chemistry :");
        c = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input the marks obtained in Mathematics :");
        m = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine();
        Console.WriteLine("Total marks of Maths, Physics and Chemistry : {0}", m + p + c);
        Console.WriteLine("Total marks of Maths and Physics : {0}", m + p);
        Console.WriteLine();
        if (m >= 65)
            if (p >= 55)
                if (c >= 50)
                    if ((m + p + c) >= 180 || (m + p) >= 140)
                        Console.WriteLine("The candidate is eligible for admission.");
                    else
                        Console.WriteLine("The candidate is not eligible for admission.");
                else
                    Console.WriteLine("The candidate is not eligible for admission.");
            else
                Console.WriteLine("The candidate is not eligible for admission.");
        else
            Console.WriteLine("The candidate is not eligible for admission.");
    }
}