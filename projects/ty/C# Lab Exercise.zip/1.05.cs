﻿// Made by Bhavya Popat
using System;
public class Program5
{
    public static void Main()
    {
        Console.Write("Input the First Number : ");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.Write("Input the Second Number : ");
        int y = Convert.ToInt32(Console.ReadLine());
        int temp;
        temp = x;
        x = y;
        y = temp;
        Console.WriteLine("After Swapping :");
        Console.WriteLine("First Number : " + x);
        Console.WriteLine("Second Number : " + y);
    }
}