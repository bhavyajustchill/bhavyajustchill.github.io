﻿// Made by Bhavya Popat
using System;
public class Program9
{
    public static void Main()
    {
        string answer;
        string result;

        Console.Write("Number to convert (or \"end\")? ");
        answer = Console.ReadLine();

        int num = Convert.ToInt32(answer);
        result = "";
        while (num > 1)
        {
            int remainder = num % 2;
            result = Convert.ToString(remainder) + result;
            num /= 2;
        }
        result = Convert.ToString(num) + result;
        Console.WriteLine("Binary: {0}", result);
    }
}