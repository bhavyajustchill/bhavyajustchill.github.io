﻿// Made by Bhavya Popat
using System;
public class Program16
{
    public static void Main()
    {
        float PerHeight;

        Console.Write("Enter height (in cm): ");
        PerHeight = Convert.ToInt32(Console.ReadLine());

        if (PerHeight < 150.0)
            Console.WriteLine("The person is Dwarf.");
        else if ((PerHeight == 150.0))
            Console.WriteLine("The person is Average Heighted.");
        else if ((PerHeight > 150.0))
            Console.WriteLine("The person is Tall.");
    }
}