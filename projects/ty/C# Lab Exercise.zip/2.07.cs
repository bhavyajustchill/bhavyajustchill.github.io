﻿// Made by Bhavya Popat
using System;
public class Program7
{
    public static void Main()
    {
        char symbol;

        Console.Write("Input a symbol: ");
        symbol = Convert.ToChar(Console.ReadLine());

        if ((symbol == 'a') || (symbol == 'e') || (symbol == 'i') ||
                (symbol == 'o') || (symbol == 'u'))
            Console.WriteLine("It's a lowercase vowel.");
        else if ((symbol >= '0') && (symbol <= '9'))
            Console.WriteLine("It's a digit.");
        else
            Console.WriteLine("It's another symbol.");
    }
}