/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.*;
import javax.swing.JApplet;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author Bhavya Popat
 */
public class Job1 extends JApplet implements ActionListener {

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    
    JLabel title = new JLabel("JOB APPLICATION",JLabel.CENTER);
    JLabel nm = new JLabel("Name",JLabel.RIGHT);
    JLabel add = new JLabel("Address",JLabel.RIGHT);
    JLabel qf = new JLabel("Qualification",JLabel.RIGHT);
    JLabel ph = new JLabel("Phone Number",JLabel.RIGHT);
    JLabel eid = new JLabel("Email ID",JLabel.RIGHT);
    JLabel xp = new JLabel("Experience(y/m)",JLabel.RIGHT);
    JLabel years = new JLabel("Years");
    JLabel months = new JLabel("months");
    JLabel pltfrm = new JLabel("Platform",JLabel.RIGHT);
    JLabel dob = new JLabel("Date Of Birth",JLabel.RIGHT);
    JLabel sex = new JLabel("Gender",JLabel.RIGHT);
    JLabel info = new JLabel("",JLabel.CENTER);
    JTextArea name = new JTextArea(1,20);
    JTextArea address = new JTextArea(1,100);
    JTextField phone = new JTextField(20);
    JTextField email = new JTextField(20);
    JTextField expYears = new JTextField(20);
    JTextField expMonths = new JTextField(20);
    JRadioButton male = new JRadioButton("MALE");
    JRadioButton female = new JRadioButton("FEMALE");
    ButtonGroup gender = new ButtonGroup();
    JButton submit = new JButton("SUBMIT");
    String[] qualifications = {"Select One","SSC","HSC","UG","PG","Ph.D"};
    String[] platforms = {"Select One","C","C++","C#.NET","HTML/CSS","PHP","JavaScript","Java","Python","Swift","Flutter","Android","MongoDB","ASP.NET","JSP.NET","LaraVile"};
    String[] months_list = {"Month","January","Febuary","March","April","May","June","July","August","September","October","November","December"};
    String[] dates_list = {"Date","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
    String[] years_list = {"Year","2021","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009","2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995","1994","1993","1992","1991","1990","1989","1988","1987","1986","1985","1984","1983","1982","1981","1980"};
    JComboBox qualification = new JComboBox(qualifications);
    JComboBox platform = new JComboBox(platforms);
    JComboBox monthscb = new JComboBox(months_list);
    JComboBox yearscb = new JComboBox(years_list);
    JComboBox datescb = new JComboBox(dates_list);
    JPanel jp = new JPanel();
    public void init() {
        // TODO start asynchronous download of heavy resources
        setSize(665,700);
        setLayout(null);
        
        add(title);
        title.setBounds(0,0,655,30);
        
        add(nm);
        nm.setBounds(0,50,100,30);
        add(name);
        name.setBounds(120,60,127,28);
        
        add(add);
        add.setBounds(0,120,100,30);
        add(address);
        address.setBounds(120,140,105,27);
        
        add(qf);
        qf.setBounds(0,200,100,30);
        add(qualification);
        qualification.setBounds(120,210,200,34);
        
        add(ph);
        ph.setBounds(0,270,100,30);
        add(phone);
        phone.setBounds(120,280,118,28);
        
        add(eid);
        eid.setBounds(0,340,100,30);
        add(email);
        email.setBounds(120,345,118,28);
        
        add(xp);
        xp.setBounds(0,420,100,30);
        add(expYears);
        expYears.setBounds(120,420,250,28);
        add(years);
        years.setBounds(370,420,40,30);
        add(expMonths);
        expMonths.setBounds(440,420,110,28);
        add(months);
        months.setBounds(550,420,80,30);
        
        add(pltfrm);
        pltfrm.setBounds(0,500,100,30);
        add(platform);
        platform.setBounds(120,490,250,32);
        
        add(dob);
        dob.setBounds(0,560,100,30);
        add(monthscb);
        monthscb.setBounds(150,555,60,25);
        add(datescb);
        datescb.setBounds(215,555,55,25);
        add(yearscb);
        yearscb.setBounds(275,555,55,25);
        
        add(info);
        info.setBounds(350,550,315,30);
        
        add(sex);
        sex.setBounds(0,620,100,30);
        gender.add(male);
        add(male);
        male.setBounds(175,615,60,30);
        gender.add(female);
        add(female);
        female.setBounds(240,615,70,30);
        male.addActionListener(this);
        female.addActionListener(this);
       
        add(submit);
        submit.setBounds(0,670,665,25);
        submit.addActionListener(this);
    }
    
    // TODO overwrite start(), stop() and destroy() methods

    @Override
    public void actionPerformed(ActionEvent ae) {
        //To change body of generated methods, choose Tools | Templates.
        if(ae.getSource() == submit)
        {
            if(name.getText().isEmpty() || address.getText().isEmpty() || qualification.getSelectedItem().toString().equals("Select One") || phone.getText().isEmpty() || email.getText().isEmpty() || expMonths.getText().isEmpty() || expYears.getText().isEmpty() || platform.getSelectedItem().toString().equals("Select One") || monthscb.getSelectedItem().toString().equals("Month") || datescb.getSelectedItem().toString().equals("Date") || yearscb.getSelectedItem().toString().equals("Year") || gender.getSelection()==null)
            {
                info.setBounds(325,50,330,30);
                info.setText("Error: All the fields are compulsory and cannot be Empty!");
            }
            else
            {
                String name1 = name.getText();
                String address1 = address.getText();
                String qualification1 = qualification.getSelectedItem().toString();
                String phone1 = phone.getText();
                String email1 = email.getText();
                String d1 = expMonths.getText();
                String d2 = expYears.getText();
                String date1 = d2+"/"+d1;
                String platform1 = platform.getSelectedItem().toString();
                String dob1 = datescb.getSelectedItem().toString();
                String dob2 = monthscb.getSelectedItem().toString();
                String dob3 = yearscb.getSelectedItem().toString();
                String birthdate1 = dob1+"/"+dob2+"/"+dob3;
                String gender1 = null;
                if(male.isSelected())
                    gender1 = "MALE";
                else if(female.isSelected())
                    gender1 = "FEMALE";
                
                try
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bbp_java_ass1","root","");
                    Statement st = con.createStatement();
                    String sql = "insert into job1(name,address,qualification,contact,email,experience,platform,birthdate,gender) values ('"+name1+"', '"+address1+"', '"+qualification1+"', '"+phone1+"', '"+email1+"', '"+date1+"', '"+platform1+"', '"+birthdate1+"', '"+gender1+"');";
                    st.executeUpdate(sql);
                    
                    info.setText("Applied for Job Successfully!");
                    info.setBounds(325,50,330,30);
                }
                catch(Exception e)
                {
                    info.setText(e.toString());
                    info.setBounds(350,550,1000,30);
                }    
            }
        }
    }
}
