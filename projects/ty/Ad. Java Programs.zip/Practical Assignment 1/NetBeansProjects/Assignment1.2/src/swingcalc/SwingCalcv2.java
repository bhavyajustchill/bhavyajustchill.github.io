/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swingcalc;

import javax.swing.*;
import javax.swing.JApplet;
import java.awt.*;
import java.awt.event.*;
import javax.script.*;

/**
 *
 * @author Bhavya Popat
 */
public class SwingCalcv2 extends JApplet implements ActionListener {
    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    JPanel jp = new JPanel();
    JPanel jp1 = new JPanel();
    JTextField deq = new JTextField("0");
    JButton b1 = new JButton("1");
    JButton b2 = new JButton("2");
    JButton b3 = new JButton("3"); 
    JButton b4 = new JButton("4");
    JButton b5 = new JButton("5");
    JButton b6 = new JButton("6");
    JButton b7 = new JButton("7");
    JButton b8 = new JButton("8");
    JButton b9 = new JButton("9");
    JButton b0 = new JButton("0");
    JButton bAdd = new JButton("+");
    JButton bSub = new JButton("-");
    JButton bProd = new JButton("*");
    JButton bDiv = new JButton("/");
    JButton bEqual = new JButton("=");
    JButton bClear = new JButton("C");
    /**
     *
     */
    @Override
    public void init() {
        // TODO start asynchronous download of heavy resources
        
        setSize(400,180);
        Frame c1 = (Frame)this.getParent().getParent();
        c1.setTitle("Swing Calculator");
        
        jp1.setLayout (new BorderLayout());
        jp1.add("Center",deq);
        deq.setHorizontalAlignment(JTextField.RIGHT);
        deq.setEditable(false);
        jp.setLayout (new GridLayout(4,4,8,8));
        
        jp.add(b7);
        jp.add(b8);
        jp.add(b9);
        jp.add(bAdd);
        
        jp.add(b4);
        jp.add(b5);
        jp.add(b6);
        jp.add(bSub);
        
        jp.add(b1);
        jp.add(b2);
        jp.add(b3);
        jp.add(bProd);
        
        jp.add(bClear);
        jp.add(b0);
        jp.add(bEqual);
        jp.add(bDiv);
        
        add("North",jp1);
        add("Center",jp);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        b8.addActionListener(this);
        b9.addActionListener(this);
        b0.addActionListener(this);
        bAdd.addActionListener(this);
        bSub.addActionListener(this);
        bProd.addActionListener(this);
        bDiv.addActionListener(this);
        bEqual.addActionListener(this);
        bClear.addActionListener(this);
        
        
        
    }

    // TODO overwrite start(), stop() and destroy() methods

   
    public void actionPerformed(ActionEvent ae) {
        //To change body of generated methods, choose Tools | Templates.
        
        if(ae.getSource() == bClear)
        {
            deq.setText("0");          
        }
        if(ae.getSource() == bEqual)
        {
            deq.setText(calculate(deq.getText()));
        }
        if(deq.getText().equals("0"))
        {
            if(ae.getSource() == b1)
            {
                deq.setText("1");  
            }
            if(ae.getSource() == b2)
            {
                deq.setText("2");          
            }
            if(ae.getSource() == b3)
            {
                deq.setText("3");          
            }
            if(ae.getSource() == b4)
            {
                deq.setText("4");          
            }
            if(ae.getSource() == b5)
            {
                deq.setText("5");          
            }
            if(ae.getSource() == b6)
            {
                deq.setText("6");          
            }
            if(ae.getSource() == b7)
            {
                deq.setText("7");          
            }
            if(ae.getSource() == b8)
            {
                deq.setText("8");          
            }
            if(ae.getSource() == b9)
            {
                deq.setText("9");          
            }    
        }
        else
        {
            if(ae.getSource() == b1)
            {
                deq.setText(deq.getText()+"1");          
            }
            if(ae.getSource() == b2)
            {
                deq.setText(deq.getText()+"2");          
            }
            if(ae.getSource() == b3)
            {
                deq.setText(deq.getText()+"3");          
            }
            if(ae.getSource() == b4)
            {
                deq.setText(deq.getText()+"4");          
            }
            if(ae.getSource() == b5)
            {
                deq.setText(deq.getText()+"5");          
            }
            if(ae.getSource() == b6)
            {
                deq.setText(deq.getText()+"6");          
            }
            if(ae.getSource() == b7)
            {
                deq.setText(deq.getText()+"7");          
            }
            if(ae.getSource() == b8)
            {
                deq.setText(deq.getText()+"8");          
            }
            if(ae.getSource() == b9)
            {
                deq.setText(deq.getText()+"9");          
            }
            if(ae.getSource() == b0)
            {
                deq.setText(deq.getText()+"0");          
            }
            if(ae.getSource() == bAdd)
            {
                deq.setText(deq.getText()+" + ");  
            }
            if(ae.getSource() == bSub)
            {
                deq.setText(deq.getText()+" - "); 
            }
            if(ae.getSource() == bProd)
            {
                deq.setText(deq.getText()+" * ");     
            }
            if(ae.getSource() == bDiv)
            {
                deq.setText(deq.getText()+" / ");
            }
        }
    }
    public String calculate(String sq) {
        ScriptEngineManager mgr = new ScriptEngineManager();
        ScriptEngine engine = mgr.getEngineByName("JavaScript");
        Object result = null;
        try {
                result = engine.eval(sq);
        } 
        catch (ScriptException ex) {
                result = ex.toString();
        }
        return result.toString();
    }
}