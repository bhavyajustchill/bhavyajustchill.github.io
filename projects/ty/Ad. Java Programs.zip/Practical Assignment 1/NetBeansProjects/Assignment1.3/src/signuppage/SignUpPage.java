/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package signuppage;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author Bhavya Popat
 */
public class SignUpPage extends JApplet implements ActionListener {

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    
    JTextField username = new JTextField(20);
    JPasswordField password = new JPasswordField(20);
    JPasswordField passconfirm = new JPasswordField(20);
    JButton submit = new JButton("Submit");
    JLabel info = new JLabel();
    JLabel uname = new JLabel("Enter Username:",JLabel.RIGHT);
    JLabel pwd = new JLabel("Enter Password:",JLabel.RIGHT);
    JLabel pwdconf = new JLabel("Confirm Password:",JLabel.RIGHT);
    public void init() {
        // TODO start asynchronous download of heavy resources
        setSize(400,250);
        Frame c1 = (Frame)this.getParent().getParent();
        c1.setTitle("Sign Up Page");
        setLayout(null);
        add(uname);
        add(username);
        add(pwd);
        add(password);
        add(pwdconf);
        add(passconfirm);
        add(submit);
        add(info);
        uname.setBounds(0,10,130,22);
        username.setBounds(150,10,180,22);
        pwd.setBounds(0,50,130,22);
        password.setBounds(150, 50, 180, 22);
        pwdconf.setBounds(0,90,130,22);
        passconfirm.setBounds(150, 90, 180, 22);
        submit.setBounds(125, 140, 95, 27);
        submit.addActionListener(this);
                
    }

    // TODO overwrite start(), stop() and destroy() methods

    @Override
    public void actionPerformed(ActionEvent ae) {
        //To change body of generated methods, choose Tools | Templates.
        if(ae.getSource() == submit)
        {
            String s0 = username.getText();
            String s1 = password.getText();
            String s2 = passconfirm.getText();
            if(username.getText().isEmpty())
            {
                info.setText("Error: Username is Empty!");
                info.setBounds(100,170,300,22);
            }
            else
            {
                if(s1.equals(s2))
                {
                    try
                    {
                        Class.forName("com.mysql.jdbc.Driver");
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bbp_java_ass1","root","");
                        Statement st = con.createStatement();
                        String sql="insert into login (username,password) values('"+s0+"', '"+s1+"');";
                        st.executeUpdate(sql);
                        
                        info.setText("Sign Up Successful!");
                        info.setBounds(115,170,200,22);
                    }
                    catch(Exception e)
                    {
                        info.setText(e.toString());
                        info.setBounds(0,170,1000,22);
                    }
                }
                else
                {
                info.setText("Error: Passwords Don't Match!");
                password.setText("");
                passconfirm.setText("");
                info.setBounds(90,170,300,22);
                }
            }
        }
    }
}
