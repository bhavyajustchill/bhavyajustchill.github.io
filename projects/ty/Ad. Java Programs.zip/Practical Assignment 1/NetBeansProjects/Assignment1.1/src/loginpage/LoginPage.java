/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;

/*<applet code="LoginPage.class" width="300" height="300"> </applet>*/

/**
 *
 * @author Bhavya Popat
 */
public class LoginPage extends JApplet implements ActionListener {
    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    JButton b = new JButton("Login");  
    JTextField tf = new JTextField(20);
    JPasswordField pw = new JPasswordField(20);
    JLabel l = new JLabel();
    public void init() {
        // TODO start asynchronous download of heavy resources
       setSize(350,160);
       Frame c1 = (Frame)this.getParent().getParent();
       c1.setTitle("Login Authentication");
       setLayout(null);
       add(tf);  
       add(pw);
       add(b);
       tf.setBounds(85,10,180,22);
       pw.setBounds(85,50,180,22);
       b.setBounds(135,90,75,22);
       add(l);
       b.addActionListener(this);
 
    }

    // TODO overwrite start(), stop() and destroy() methods

    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource() == b)
        {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bbp_java_ass1","root","");
                String username = tf.getText();
                String password = pw.getText();
                Statement st = con.createStatement();
                String sql = "select * from login where username='"+username+"' and password='"+password+"'";
                ResultSet rs = st.executeQuery(sql);
                if(rs.next())
                {
                    l.setBounds(125,120,150,25);
                    l.setText("Login Successful!");
                    HomePage hpage = new HomePage();
                    hpage.show();
                    
                }
                else
                {
                    l.setBounds(95,120,200,25);
                    l.setText("Login Failed! Please Try Again!");
                    tf.setText("");
                    pw.setText("");
                }
            }
            catch (Exception e)
            {
                l.setBounds(0,120,2000,20);
                l.setText(e.toString());
            }
        }
    }

   
}
