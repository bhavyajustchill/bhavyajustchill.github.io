/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gridbagbuttons;

import java.awt.*;
import javax.swing.JApplet;
import javax.swing.*;
/**
 *
 * @author Bhavya Popat
 */
public class GridBagButtons extends JApplet {

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    JButton b1 = new JButton("Button #1");
    JButton b2 = new JButton("Button #2");
    JButton b3 = new JButton("Button #3");
    JButton b4 = new JButton("Button #4");
    JButton b5 = new JButton("Button #5");
    JButton b6 = new JButton("Button #6");
    JButton b7 = new JButton("Button #7");
    JButton b8 = new JButton("Button #8");
    JButton b9 = new JButton("Button #9");
    GridBagConstraints gbc = new GridBagConstraints();
    public void init() {
        // TODO start asynchronous download of heavy resources
        setSize(500,180);
        Frame c1 = (Frame)this.getParent().getParent();
        c1.setTitle("");
        setLayout(new GridBagLayout());
        gbc.insets = new Insets(5,5,5,5);        
        
        gbc.gridx=0;
        gbc.gridy=0;
        gbc.gridheight=3;
        gbc.gridwidth=4;
        gbc.fill=GridBagConstraints.BOTH;
        
        add(b1, gbc);
        
        gbc.gridx=4;
        gbc.gridy=0;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        add(b2,gbc);
        
        gbc.gridx=4;
        gbc.gridy=1;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        add(b3,gbc);
        
        gbc.gridx=4;
        gbc.gridy=2;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        add(b4,gbc);
        
        gbc.gridx=0;
        gbc.gridy=5;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        add(b5,gbc);
        
        gbc.gridx=2;
        gbc.gridy=5;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        add(b6,gbc);
        
        gbc.gridx=3;
        gbc.gridy=5;
        gbc.gridheight=1;
        gbc.gridwidth=2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(b7,gbc);
        
        gbc.gridx=1;
        gbc.gridy=6;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        add(b8,gbc);
        
        gbc.gridx=3;
        gbc.gridy=6;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        add(b9,gbc);
    }

    // TODO overwrite start(), stop() and destroy() methods
}
