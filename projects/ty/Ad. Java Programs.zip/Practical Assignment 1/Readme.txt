Name: Bhavya B. Popat
Class: F2-Y
Roll No.: 44
Enrollment No.:190802088
Ad. Java Practical Assignment-1

All the programs done in form of NetBeans Projects individually, and their entire Project Folders provided in NetBeansProjects directory.

the database for this assignment is provided for importing in XAMPP's phpMyAdmin (if it doesn't work, download my version of XAMPP: https://drive.google.com/file/d/1jlrcOOZ44E-IFkZt_BoO-_vIgcfJNhEM/view?usp=sharing)

JAR file of MySQL connector is provided which works well for JDBC Connectivity in the form of Driver.

For 1st Program, username is "bhavya" and password is "bbp"