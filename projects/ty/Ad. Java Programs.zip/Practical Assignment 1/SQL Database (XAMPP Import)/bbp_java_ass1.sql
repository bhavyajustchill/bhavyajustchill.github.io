-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2021 at 10:55 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bbp_java_ass1`
--

-- --------------------------------------------------------

--
-- Table structure for table `job1`
--

CREATE TABLE IF NOT EXISTS `job1` (
`id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(300) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `experience` varchar(10) NOT NULL,
  `platform` varchar(20) NOT NULL,
  `birthdate` varchar(15) NOT NULL,
  `gender` varchar(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job1`
--

INSERT INTO `job1` (`id`, `name`, `address`, `qualification`, `contact`, `email`, `experience`, `platform`, `birthdate`, `gender`) VALUES
(1, 'Bhavya', 'Kalawad Road, Rajkot - 360005', 'HSC', '6354546061', 'bbp@yahoo.com', '1/6', 'Java', '08/June/2001', 'MALE'),
(2, 'Maharshi', 'Unknown Road, Jamnagar', 'HSC', '7600032603', 'thefast@gmail', '0/9', 'Python', '26/March/2002', 'MALE'),
(3, 'Smeet', 'Somewhere in Rajkot', 'HSC', '9876543210', 'smeet14@hotmail', '14/2', 'C#.NET', '14/June/2001', 'MALE'),
(5, 'Franklin', 'Ocean View, Apt 5, Los Santos', 'PG', '1126587798', 'franklinc@eyefind', '8/1', 'C++', '20/March/1988', 'MALE');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
`id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'bhavya', 'bbp'),
(2, 'bhavyapopat', 'bbpnew'),
(3, 'zzz', '1469');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `job1`
--
ALTER TABLE `job1`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `job1`
--
ALTER TABLE `job1`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
