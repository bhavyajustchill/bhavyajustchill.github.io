/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JApplet;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author Bhavya Popat
 */
public class ButtonLayout extends JApplet {

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    JButton b1 = new JButton("1");
    JButton b2 = new JButton("2");
    JButton b3 = new JButton("3");
    JButton b4 = new JButton("4");
    JButton b5 = new JButton("5");
    JButton b6 = new JButton("6");
    JButton b7 = new JButton("7");
    GridBagConstraints gbc = new GridBagConstraints();

    public void init() {
        // TODO start asynchronous download of heavy resources
        setSize(300,300);
        setLayout(new GridBagLayout());
        gbc.gridx=0;
        gbc.gridy=0;
        gbc.gridheight=1;
        gbc.gridwidth=1;
        gbc.ipadx=20;
        gbc.ipady=75;
        gbc.fill=GridBagConstraints.BOTH;
        add(b1,gbc);
        gbc.gridx=1;
        add(b2,gbc);
        gbc.gridx=2;
        add(b3,gbc);
        gbc.gridx=3;
        add(b4,gbc);
        gbc.gridx=4;
        add(b5,gbc);
        gbc.gridx=0;
        gbc.gridy=3;
        gbc.gridwidth=5;
        add(b6,gbc);
        gbc.gridy=6;
        add(b7,gbc);
    }
    // TODO overwrite start(), stop() and destroy() methods
}
