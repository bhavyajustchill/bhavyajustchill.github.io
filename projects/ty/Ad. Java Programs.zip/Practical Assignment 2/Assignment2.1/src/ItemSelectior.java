/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JApplet;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/**
 *
 * @author Bhavya Popat
 */
public class ItemSelectior extends JApplet implements ActionListener{
    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    JRadioButton red = new JRadioButton("Red");
    JRadioButton green = new JRadioButton("Green");
    JRadioButton blue = new JRadioButton("Blue");
    ButtonGroup bgp = new ButtonGroup();
    JPanel btnbar = new JPanel();
    JPanel background = new JPanel();
    public void init() {
        // TODO start asynchronous download of heavy resources
        setSize(250,150);
        bgp.add(red);
        bgp.add(green);
        bgp.add(blue);
        btnbar.add(red);
        btnbar.add(green);
        btnbar.add(blue);
        red.addActionListener(this);
        green.addActionListener(this);
        blue.addActionListener(this);
        add(btnbar, BorderLayout.NORTH);
        add(background, BorderLayout.CENTER);
    }

    // TODO overwrite start(), stop() and destroy() methods

    @Override
    public void actionPerformed(ActionEvent ae) {
        //To change body of generated methods, choose Tools | Templates.
        if(ae.getSource() == red)
        {
            btnbar.setBackground(Color.RED);
            background.setBackground(Color.RED);
        }
        if(ae.getSource() == green)
        {
            btnbar.setBackground(Color.GREEN);
            background.setBackground(Color.GREEN);
        }
        if(ae.getSource() == blue)
        {
            btnbar.setBackground(Color.BLUE);
            background.setBackground(Color.BLUE);
        }
    }
} 