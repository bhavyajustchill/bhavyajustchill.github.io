/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.JApplet;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Bhavya Popat
 */
public class Scrollv2 extends JApplet implements AdjustmentListener{

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    private JScrollBar rBar, gBar, bBar;
    private ColorCanvas cs;
    public void init() {
        // TODO start asynchronous download of heavy resources
        setSize(300,110);
        JPanel rightPanel = new JPanel();
	
	  rBar = new JScrollBar(Scrollbar.HORIZONTAL, 4, 0, 0, 255);
	  rBar.addAdjustmentListener(this);
	  rightPanel.add(rBar);
	  gBar = new JScrollBar(Scrollbar.HORIZONTAL, 95, 0, 0, 255);
	  gBar.addAdjustmentListener(this);
	  rightPanel.add(gBar);
	  bBar = new JScrollBar(Scrollbar.HORIZONTAL, 20, 0, 0, 255);
	  bBar.addAdjustmentListener(this);
	  rightPanel.add(bBar);
	  cs = new ColorCanvas();
	  cs.setSize(53,52);
	  this.add(cs,BorderLayout.CENTER);
	  this.add(rightPanel,BorderLayout.NORTH);
	  this.updateColor();
    }

    // TODO overwrite start(), stop() and destroy() methods

   

    private void updateColor()
    {
        Color c = new Color(rBar.getValue(), gBar.getValue(), bBar.getValue());
        cs.updateColor(c);
    }
    
    @Override
    public void adjustmentValueChanged(AdjustmentEvent ae) {
        //To change body of generated methods, choose Tools | Templates.
	  this.updateColor();
    }
}
  class ColorCanvas extends Canvas
  {
	private Color col;

	public void updateColor(Color c)
	{
	  this.col = c;
	  repaint();
	}

        @Override
	public void paint(Graphics g)
	{
	  g.setColor(col);
	  g.fillRect(45,30,53,52);
	}
  }