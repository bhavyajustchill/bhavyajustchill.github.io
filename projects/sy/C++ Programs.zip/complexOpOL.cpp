//Made By Bhavya Popat
#include<iostream>
using namespace std;
class complex
{
	int real,image;
	public:
	void set()
	{
		cout<<"Enter Real and Imaginary Numbers : ";
		cin>>real>>image;
	}
	friend complex operator+(complex,complex);
	void display()
	{
		cout<<"Sum : "<<real<<" + "<<image<<"i\n";
	}
};
complex operator+(complex t1,complex t2)
{
	complex temp;
	temp.real=t1.real+t2.real;
	temp.image=t1.image+t2.image;
	return temp;
}
int main()
{
	complex t1,t2;
	cout<<"Complex No. 1\n";
	t1.set();
	cout<<"Complex No. 2\n";
	t2.set();
	t1=t1+t2;
	t1.display();
	return 0;
}
