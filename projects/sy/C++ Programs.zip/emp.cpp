//Program by Bhavya Popat, E2 - 48
#include<iostream>
#include<iomanip>
using namespace std;
class item
{
	char emp_nm[30];
	float emp_sal;
	public:
	void getdata()
	{
		cout<<"Enter Employee Name : ";
		cin>>emp_nm;
		cout<<"Enter Employee Salary : ";
		cin>>emp_sal;
		cout<<"\n";
	}
	void putdata();
	
};
void item::putdata()
{	
	cout<<"\nEmployee Name : "<<emp_nm;
	cout<<"\nEmployee Salary : Rs. "<<emp_sal;
	cout<<"\n\n";
}
int main()
{
	class item i[100];
	int n;
	cout<<"Enter no. of Employees : ";
	cin>>n;
	for(int j=0;j<n;j++)
	{
		i[j].getdata();
	}
	for(int k=0;k<n;k++)
	{
		i[k].putdata();
	}
	return 0;
}
