#include<iostream>
using namespace std;
int main()
{
	double x=1.2345678;
	cout.width(10);
	cout.fill('$');
	cout<<"AITS\n";
	cout.precision(2);
	cout<<x;
	return 0;
}
