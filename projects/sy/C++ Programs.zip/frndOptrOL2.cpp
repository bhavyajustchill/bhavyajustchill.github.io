// Made By Bhavya Popat
#include<iostream>
using namespace std;
class B;
class A
{
	int a;
	public:
	void getdata(int i)
	{
		a=i;
	}
	void putdata()
	{
		cout<<a;
	}
	friend void operator+(B,A);
};
class B
{
	int b;
	public:
	void getdata(int i)
	{
		b=i;
	}
	void putdata()
	{
		cout<<b;
	}
	friend void operator+(B,A);
};
void operator+(B b1,A a1)
{
	cout<<b1.b<<" + "<<a1.a<<" = "<<a1.a+b1.b;
}
int main()
{
	A a;
	B b;
	a.getdata(5);
	b.getdata(6);
	b+a;
	return 0;
}
