// Made by Bhavya Popat
#include<iostream>
using namespace std;
class dynamicOperator
{
	char *p[100];
	public:
	dynamicOperator()
	{
		p[100]=new char[100];
		*p="Bhavya";
	}
	dynamicOperator(char i[100])
	{
		p[100]=new char[100];
		*p=i;
	}
	void display()
	{
		cout<<*p<<"\n";
	}
};
int main()
{
	dynamicOperator t1,t2("Popat");
	t1.display();
	t2.display();
	return 0;
}
