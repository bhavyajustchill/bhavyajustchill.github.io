//code by Bhavya Popat, E2 - 48
#include<iostream>
using namespace std;
class batsMan
{
	int batsmanCode;
	char batsmanName[20];
	int innings;
	int notOut;
	int runs;
	float battingAvg;
	float notOutAvg;
	public:
	void getdata()
	{
		cout<<"Enter Name of Player : ";
		cin>>batsmanName;
		cout<<"Enter Code : ";
		cin>>batsmanCode;
		cout<<"Enter Number of Innings : ";
		cin>>innings;
		cout<<"Enter Number of Times Not Out : ";
		cin>>notOut;
		cout<<"Enter Number of Runs : ";
		cin>>runs;
	}
	void calcAvg()
	{
		battingAvg=runs/innings;
		notOutAvg=(notOut*100)/battingAvg;
	}
	void display()
	{
		cout<<"\n\nName : "<<batsmanName;
		cout<<"\nCode : "<<batsmanCode;
		cout<<"\nNo. of Innings : "<<innings;
		cout<<"\nNo. of Times not Out : "<<notOut;
		cout<<"\nRuns : "<<runs;
		cout<<"\nBatting Average : "<<battingAvg;
		cout<<"\nNot out Average : \n\n"<<notOutAvg;
	}
};
int main()
{
	class batsMan bm[5];
	for(int i=0;i<5;i++)
	{
		bm[i].getdata();
	}
	for(int j=0;j<5;j++)
	{
		bm[j].display();
	}
	return 0;
}
