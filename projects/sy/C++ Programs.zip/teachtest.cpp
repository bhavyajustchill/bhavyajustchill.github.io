#include<iostream>
using namespace std;
class test
{
	public:
		int block;
		test(int count)
		{
			block=count;
			cout<<count<<" object(s) created\n";
		}
		~test()
		{
			cout<<block<<" object(s) destroyed\n";
			block--;
		}
};
int main()
{
	test t1(1);
	{
		test t2(2);
		{
			test t3(3);
		}
	}
	return 0;
}
