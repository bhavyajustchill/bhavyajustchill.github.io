//Made By Bhavya Popat - E2 (48)
#include<iostream>
using namespace std;
float area(float r)
{
        return(3.14 * r * r);
}
float area(float b,float h)
{
        return(0.5 * b * h);
}
int area(int l)
{
        return (l * l);
}
int main()
{
        float b,h,r,l;
        int ch;
        do
        {
                cout<<"\n 1. Area of Circle";
                cout<<"\n 2. Area of Triangle";
                cout<<"\n 3. Area of Square";
                cout<<"\n 4. Exit";
                cout<<"\n\n Enter Your Choice : ";
                cin>>ch;
                switch(ch)
                {
                        case 1:
                        {
                                cout<<"\nEnter the Radius of Circle : ";
                                cin>>r;
                                cout<<"\nArea of Circle : "<<area(r)<<"\n";
                                break;
                        }
                        case 2:
                        {
                                cout<<"\nEnter the Base & Height of Triangle : ";
                                cin>>b>>h;
                                cout<<"\nArea of Triangle : "<<area(b,h)<<"\n";
                                break;
                        }
                        case 3:
                        {
                                cout<<"\nEnter the Length of Square : ";
                                cin>>l;
                                cout<<"\nArea of Square : "<<area(l)<<"\n";
                                break;
                        }
                        case 4:
                                exit(0);
                        default:
                                cout<<"\nInvalid Choice! Please Enter a Valid Choice!";
                }
        }while(ch!=4);
        return 0;
}
