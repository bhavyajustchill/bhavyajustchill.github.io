// Made By Bhavya Popat
#include<iostream>
using namespace std;
class Weight
{
	int kg,gram;
	public:
		Weight()
		{
			cout<<"Enter Weight (in kg) : ";
			cin>>kg;
			cout<<"Enter Weight (in grams) : ";
			cin>>gram;
			kg=kg+gram/1000;
			gram%=1000;
		}
		void displayWeight()
		{
			cout<<"\n"<<kg<<" Kg "<<gram<<" g\n";
		}
};
int main()
{
	Weight w1;
	w1.displayWeight();
	return 0;
}
