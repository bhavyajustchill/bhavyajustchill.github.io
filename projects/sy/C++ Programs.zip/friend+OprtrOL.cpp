// Made By Bhavya Popat
#include<iostream>
using namespace std;
class B;
class A
{
	int a;
	public:
	void getdata(int i)
	{
		a=i;
	}
	void putdata()
	{
		cout<<a;
	}
	friend void operator+(A,B);
};
class B
{
	int b;
	public:
	void getdata(int i)
	{
		b=i;
	}
	void putdata()
	{
		cout<<b;
	}
	friend void operator+(A,B);
};
void operator+(A a1,B b1)
{
	cout<<a1.a<<" + "<<b1.b<<" = "<<a1.a+b1.b;
}
int main()
{
	A a;
	B b;
	a.getdata(5);
	b.getdata(6);
	a+b;
	return 0;
}
