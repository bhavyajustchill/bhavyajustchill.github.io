#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ofstream fout;
	fout.open("cpp fh1.txt");
	fout<<"First File Handling File of CPP!";
	return 0;
}
