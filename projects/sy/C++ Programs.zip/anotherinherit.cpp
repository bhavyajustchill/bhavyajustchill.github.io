//Made by Bhavya Popat
#include<iostream>
using namespace std;
class windows
{
	public:
		void ui()
		{
			cout<<"Graphical User Interface\n";
		}
		void fileSystem()
		{
			cout<<"MS DOS File System\n";
		}
};
class windowsXP : public windows
{
	public:
		void fileExplorer()
		{
			cout<<"Windows Explorer\n";
		}
		void multiTask()
		{
			cout<<"Multitasking Enabled\n";
		}
};
class windows7 : public windowsXP
{
	public:
		void themeing()
		{
			cout<<"Aero Glass Enabled!\n";
		}
};
class windows8 : public windows7
{
	public:
		void metro()
		{
			cout<<"Metro Styled Icons Enabled!\n";
		}
};
class windows10 : public windows8
{
	public:
		void microsoftApps()
		{
			cout<<"Microsoft Apps available as default!\n";
		}
};
int main()
{
	windows w1;
	windowsXP w2;
	windows7 w3;
	windows8 w4;
	windows10 w5;
	w5.microsoftApps();
	w5.fileSystem();
	w5.metro();
	w5.themeing();
	w5.multiTask();
	w5.ui();
	return 0;
}

