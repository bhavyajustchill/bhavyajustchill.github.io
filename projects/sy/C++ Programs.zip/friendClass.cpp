//Made by Bhavya Popat (Class Friend)
#include<iostream>
using namespace std;
class A
{
	int x;
	public:
		void getdata(int i)
		{
			x=i;
		}
		friend class B;
};
class B
{
	public:
		void putdata(A a1)
		{
			cout<<"Class B fetched private variable from Class A : "<<a1.x;
		}
};
int main()
{
	A a1;
	B b1;
	int i;
	cout<<"Enter A Number : ";
	cin>>i;
	a1.getdata(i);
	b1.putdata(a1);
	return 0;
}
