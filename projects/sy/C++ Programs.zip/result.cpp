// Code by Bhavya Popat, B.Sc. IT E2 [R.No. 48]
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	float s1,s2,s3,s4,s5,t,p;
	cout<<"Enter C++ Marks : ";
	cin>>s1;
	cout<<"\nEnter Oracle Marks : ";
	cin>>s2;
	cout<<"\nEnter Advance English Marks : ";
	cin>>s3;
	cout<<"\nEnter BDE Marks : ";
	cin>>s4;
	cout<<"\nEnter OS Marks : ";
	cin>>s5;
	t=s1+s2+s2+s4+s5;
	p=t/5;
	cout<<"\n\nAdvance English : \t"<<setw(5)<<setprecision(3)<<s3<<endl;
	cout<<"C++ : \t\t\t"<<setw(5)<<setprecision(3)<<s1<<endl;
	cout<<"Oracle : \t\t"<<setw(5)<<setprecision(3)<<s2<<endl;
	cout<<"BDE : \t\t\t"<<setw(5)<<setprecision(3)<<s4<<endl;
	cout<<"OS : \t\t\t"<<setw(5)<<setprecision(3)<<s5<<endl;
	cout<<"==========================================";
	cout<<"\nTotal : \t\t"<<setw(5)<<setprecision(3)<<t<<endl;
	cout<<"Percentage : \t\t"<<setw(5)<<p<<endl;
	return 0;
}
