// Made By Bhavya Popat
#include<iostream>
using namespace std;
class A
{
	public:
		int x;
		int *pv=&x;
		void putdata()
		{
			cout<<*pv<<"\n";
		}
};
int main()
{
	A a1;
	A *p2;
	p2=&a1;
	int A::*pv=&A::x;
	a1.*pv=10;
	a1.putdata();
	p2->*pv=20;
	p2->putdata();
	return 0;
}
