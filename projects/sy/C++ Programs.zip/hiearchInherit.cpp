// Made By Bhavya Popat
#include<iostream>
using namespace std;
class product
{
	public:
	int pid,price;
	char pname[20];
	void getinfo()
	{
		cout<<"Enter Price : ";
		cin>>price;
		cout<<"Enter Product Name : ";
		cin>>pname;
		cout<<"Enter Product ID : ";
		cin>>pid;
	}
	void display()
	{
		cout<<"\nProduct ID : "<<pid;
		cout<<"\nProduct Name : "<<pname;
		cout<<"\nPrice : Rs. "<<price;
	}
};
class food : public product
{
	public:
	char color[10];
	int expiry;
	void getData()
	{
		cout<<"Enter the Colour : ";
		cin>>color;
		cout<<"Enter Expiry Date : ";
		cin>>expiry;
	}
	void displayFood()
	{
		cout<<"\nColor : "<<color;	
		cout<<"\nExpiry : "<<expiry<<" Months";
	}
};
class cloth : public product
{
	public:
	int size;
	char material[20];
	void getData()
	{
		cout<<"Enter Size : ";
		cin>>size;
		cout<<"Enter the Type of Material : ";
		cin>>material;
	}
	void displayCloth()
	{
		cout<<"\nMaterial : "<<material;
		cout<<"\nSize : "<<size;
	}
};
int main()
{
	product p1;
	cloth c1;
	food f1;
	int ch;
	cout<<"\n1. Food";
	cout<<"\n2. Cloth";
	cout<<"\nEnter your Choice [1/2] : ";
	cin>>ch;
	if(ch==1)
	{
		f1.getinfo();
		f1.getData();
		f1.display();
		f1.displayFood();
	}
	else if(ch==2)
	{
		c1.getinfo();
		c1.getData();
		c1.display();
		c1.displayCloth();
	}
	return 0;
}
