//Code by Bhavya Popat, B.Sc. IT - E2 [48]
#include<iostream>
using namespace std;
int main()
{
	int *p=new int;
	cout<<"Enter value of P : ";
	cin>>*p;
	cout<<"P : "<<*p;
	delete p;
	if(p==NULL)
	{
		cout<<"\nP deleted succesfully!";
	}
	return 0;
}
