//Made by Bhavya Popat (Class Friend)
#include<iostream>
using namespace std;
class A
{
	int x;
	public:
		void getdata(int i,int j)
		{
			x=i*j;
		}
		friend class B;
};
class B
{
	public:
		void putdata(A a1)
		{
			cout<<"Product : "<<a1.x;
		}
};
int main()
{
	A a1;
	B b1;
	int i,j;
	cout<<"Enter two Numbers : ";
	cin>>i>>j;
	a1.getdata(i,j);
	b1.putdata(a1);
	return 0;
}
