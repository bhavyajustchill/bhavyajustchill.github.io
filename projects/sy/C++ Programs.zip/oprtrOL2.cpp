// Made By Bhavya Popat
#include<iostream>
using namespace std;
class oprtr
{
	int a;
	public:
	void getData(int i)
	{
		a=i;
	}
	void operator ++()
	{
		a=++a;
	}
	void display()
	{
		cout<<a;
	}
};
int main()
{
	oprtr t1,t2;
	t1.getData(5);
	++t1;
	t1.display();
	return 0;
}
