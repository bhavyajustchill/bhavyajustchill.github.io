//Made by Bhavya Popat
#include<iostream>
using namespace std;
class A
{
	public:
		void get()
		{
			cout<<"\nClass A";
		}
};
class B : virtual public A
{
	public:
		void get()
		{
			cout<<"\nClass B";
		}
};
int main()
{
	B b1;
	A* t=&b1;
	//b1.get();
	t->get();
	return 0;
}
