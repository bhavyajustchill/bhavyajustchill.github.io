//Made by Bhavya Popat; E2 - 48
#include<iostream>
using namespace std;
class test
{
	int x;
	public:
	void getdata(int a)
	{
		x=a;
	}
	void putdata()
	{
		cout<<x<<"\n";
	}
	void max(test t1,test t2)
	{
		if(t1.x>t2.x)
			x=t1.x;
		else
			x=t2.x;
	}	
};
int main()
{
	test t1,t2,t3;
	t1.getdata(14);
	t2.getdata(69);
	t3.max(t1,t2);
	t1.putdata();
	t2.putdata();
	t3.putdata();
}
