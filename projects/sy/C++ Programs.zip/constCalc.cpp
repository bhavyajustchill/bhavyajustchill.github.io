// Made by Bhavya Popat
#include<iostream>
using namespace std;
class Calc
{
	public:
		Calc()
		{
			cout<<"\t\t\t\t\tWelcome to Bhavya's Calc!\n\n";
		}
		Calc(int a,int b)
		{
			int ch;
			cout<<"\n1. Addition";
			cout<<"\n2. Subtraction";
			cout<<"\n3. Multiplication";
			cout<<"\n4. Division";
			cout<<"\nEnter your Choice[1/2/3/4] : ";
			cin>>ch;
			cout<<"\n";
			if(ch==1)
				cout<<a<<" + "<<b<<" = "<<a+b;
			else if(ch==2)
				cout<<a<<" - "<<b<<" = "<<a-b;
			else if(ch==3)
				cout<<a<<" * "<<b<<" = "<<a*b;
			else if(ch==4)
				cout<<a<<" / "<<b<<" = "<<(float)a/b;
			else
				cout<<"Invalid Choice! Enter a Valid Choice!";
		}
};
int main()
{
	Calc c1;
	int x,y;
	cout<<"Enter 2 Values : ";
	cin>>x>>y;
	Calc c2(x,y);
	return 0;
}
