#include<iostream>
#include<iomanip>
using namespace std;
void swapv(int x,int y)
{
	int z;
	z=x;
	x=y;
	y=z;
}
void swapf(int &p,int &q)
{
	int r;
	r=p;
	p=q;
	q=r;
}
int main()
{
	int a=14,b=69;
	cout<<"Before any kind of Swap :\n"<<"A : "<<a<<"  B : "<<b<<"\n\n";
	swapv(a,b);
	cout<<"After Call By Value :\n"<<"A : "<<a<<"  B : "<<b<<"\n\n";
	swapf(a,b);
	cout<<"After Call By Functon :\n"<<"A : "<<a<<"  B : "<<b;
	return 0;
}
