// Made by Bhavya Popat
#include<iostream>
using namespace std;
char name[20];
float charge;
void assignData(int unit)
{
	if(unit<=100)
	{
		::charge=50+(0.6*unit);
	}
	else if(unit>100 && unit<=300)
	{
		::charge=110+(0.8*unit);
	}
	else if(unit>300)
	{
		::charge=270+(0.9*unit);
	}
}
void putData()
{
	cout<<"\nName of User : "<<::name;
	cout<<"\nCharge : Rs. "<<::charge;	
}
int main()
{
	int un;
	cout<<"\nEnter name : ";
	cin>>::name;
	cout<<"Enter Units Consumed : ";
	cin>>un;
	assignData(un);
	putData();
	return 0;
}
