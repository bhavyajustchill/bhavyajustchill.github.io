//Made By Bhavya
#include<iostream>
using namespace std;
class A
{
	public:
		A()
		{
			cout<<"Base Class Constructor!";
		}
		A(int x)
		{
			cout<<"\n"<<x;
		}
};
class B : public A
{
	public:
		B()
		{
			cout<<"\nDerived Class Constructor!";
		}
		B(int i) : A(i)
		{
			cout<<"\n"<<i;
		}
};
int main()
{
	B b1;
	B b2(5);
	return 0;
}
