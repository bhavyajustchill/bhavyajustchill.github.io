//Made By Bhavya Popat
#include<iostream>
using namespace std;
class Shape
{
	int height,length,area;
	public:
	void getd()
	{
		cout<<"\nEnter Height : ";
		cin>>height;
		cout<<"Enter Length : ";
		cin>>length;
	}
	void putd()
	{
		cout<<"\nHeight : "<<height;
		cout<<"\nLength : "<<length;
		cout<<"\nSurface Area : "<<area;
	}
	void surfaceArea()
	{
		area=(length*height);
	}
};
class Ract : public Shape
{};
int main()
{
	Shape s1;
	Ract r1;
	r1.getd();
	r1.surfaceArea();
	r1.putd();
	return 0;
}
