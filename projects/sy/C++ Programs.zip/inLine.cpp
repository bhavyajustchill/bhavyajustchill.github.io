//Made By Bhavya Popat
#include<iostream>
using namespace std;
inline void printName()
{
	cout<<"I am Bhavya\n";
}
int main()
{
	for(int i=0;i<5;i++)
	{
		printName();
	}
	return 0;
}
