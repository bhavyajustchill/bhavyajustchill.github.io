//Made by Bhavya Popat; E2 - 48
#include<iostream>
using namespace std;
class complex
{
	int real,image;
	public:
	void getdata(int x,int y)
	{
		real=x;
		image=y;
	}
	void putdata()
	{
		cout<<"\n Addition : "
		cout<<real<<" + ";
		cout<<image<<"i\n";
	}
	void sum(complex t2)
	{
		real=real+t2.real;
		image=image+t2.image;
	}	
};
int main()
{
	int d1,d2;
	complex t1,t2,t3;
	cout<<"Enter 1st Real & Imaginary Number : ";
	cin>>d1>>d2;
	t1.getdata(d1,d2);
	cout<<"Enter 2nd Real & Imaginary Number : ";
	cin>>d1>>d2;
	t2.getdata(d1,d2);
	t1.sum(t2);
	t1.putdata();
	return 0;
}
