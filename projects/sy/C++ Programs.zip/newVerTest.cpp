//Made By Bhavya Popat
#include<iostream>
using namespace std;
int main()
{
	int i;
	cout<<"Enter Value of I : ";
	cin>>i;
	for(int j=0;j<i;j++)
	{
		cout<<j+1<<"\n";
	}
	return 0;
}
