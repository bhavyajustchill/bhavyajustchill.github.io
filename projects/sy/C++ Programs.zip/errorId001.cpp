// Made by Bhavya Popat
#include<iostream>
using namespace std;
int gValue=10;
void extra()
{
	cout<<gValue<<' ';
}
int main()
{
	extra();
	{
		int gValue=20;
		cout<<gValue<<' ';
		cout<<:gValue<<' '; // :: aave : nai
	}
	return 0;
}
