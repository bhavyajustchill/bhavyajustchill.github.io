// Made By Bhavya Popat - LAB Assignment 1, P3
#include<iostream>
using namespace std;
class employee
{
	float empno,basic,hra,da,salary;
	char ename[30];
	float calculate()
	{
		if(basic<10000)
		{
			da=basic*0.08;
			hra=basic*0.02;	
		}
		else if(basic>=10000 && basic<20000)
		{
			da=basic*0.09;
			hra=basic*0.025;
		}
		else
		{
			da=basic*0.095;
			hra=basic*0.03;
		}
		return (salary=basic+hra+da);
	}
	public:
	void getinfo()
	{
		cout<<"Enter Employee Number : ";
		cin>>empno;
		cout<<"Enter Employee Name : ";
		cin>>ename;
		cout<<"Enter Basic Salary : ";
		cin>>basic;
		salary=calculate();
	}
	void putinfo()
	{
		cout<<"\nEmployee Number : "<<empno;
		cout<<"\nEmployee Name : "<<ename;
		cout<<"\nBasic Salary : "<<basic;
		cout<<"\nHRA : "<<hra;
		cout<<"\nDA : "<<da;
		cout<<"\nNet Salary : "<<salary;
	}
};
int main()
{
	employee e1;
	e1.getinfo();
	e1.putinfo();
	return 0;
}
