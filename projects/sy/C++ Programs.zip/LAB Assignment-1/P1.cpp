//Program by Bhavya Popat, E2 - 48 - LAB Assignment 1, P1
#include<iostream>
using namespace std;
class item
{
	char i_name[20];
	int i_no;
	float i_cost;
	public:
	void getitem()
	{
		cout<<"Enter Item No. : ";
		cin>>i_no;
		cout<<"Enter Item Name : ";
		cin>>i_name;
		cout<<"Enter Item Cost : ";
		cin>>i_cost;
		cout<<"\n";
	}
	void putitem();
};
void item::putitem()
{	
	cout<<"\nItem No. : "<<i_no;
	cout<<"\nItem Name : "<<i_name;
	cout<<"\nItem Cost : Rs. "<<i_cost;
	cout<<"\n\n";
}
int main()
{
	class item i[100];
	int n;
	cout<<"Enter no. of items : ";
	cin>>n;
	for(int j=0;j<n;j++)
	{
		i[j].getitem();
	}
	cout<<"All Items are listed below\n";
	for(int k=0;k<n;k++)
	{
		i[k].putitem();
	}
	return 0;
}
