//Made by Bhavya Popat; E2 - 48; LAB Assignment-1, P4
#include<iostream>
using namespace std;
class complex
{
	int real,image;
	public:
	void getnumber(int x,int y)
	{
		real=x;
		image=y;
	}
	friend complex sum(complex t1,complex t2)
	{
		complex temp;
		temp.real=t1.real+t2.real;
		temp.image=t1.image+t2.image;
		return temp;
	}	
	friend putnumber(complex);
};
putnumber(complex temp)
{
	cout<<"\n Addition : ";
	cout<<temp.real<<" + ";
	cout<<temp.image<<"i\n";
}
int main()
{
	int d1,d2;
	complex t1,t2,t3,temp;
	cout<<"Enter 1st Real & Imaginary Number : ";
	cin>>d1>>d2;
	t1.getnumber(d1,d2);
	cout<<"Enter 2nd Real & Imaginary Number : ";
	cin>>d1>>d2;
	t2.getnumber(d1,d2);
	temp=sum(t1,t2);
	putnumber(temp);
	return 0;
}
