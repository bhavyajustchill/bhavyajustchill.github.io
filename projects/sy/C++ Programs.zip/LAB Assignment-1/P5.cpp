// Made by Bhavya Popat; LAB Assignment-1, P5
#include<iostream>
using namespace std;
class Emp
{
	int no,salary;
	char name[20],designation[20];
	public:
	void getData()
	{
		cout<<"Enter Employee No. : ";
		cin>>no;
		cout<<"Enter Employee Name : ";
		cin>>name;
		cout<<"Enter Employee's  Designation : ";
		cin>>designation;
		cout<<"Enter Employee's Salary : ";
		cin>>salary;
		cout<<"\n";	
	}
	void putdata()
	{
		cout<<"\nEmployee No. : "<<no;
		cout<<"\nName : "<<name;
		cout<<"\nDesignation : "<<designation;
		cout<<"\nSalary : "<<salary<<"\n";
	}
};
int main()
{
	Emp e[5];
	for(int i=0;i<5;i++)
	{
		e[i].getData();
	}
	for(int j=0;j<5;j++)
	{
		e[j].putdata();
	}
	return 0;
}
