// Made by Bhavya Popat, E2; LAB Assignment-1, Friend-P1
#include<iostream>
using namespace std;
class time
{
    int hh,mm,ss;
	public:
    void gettime(int hr,int min,int sec)
    {
		hh=hr;
		mm=min;
		ss=sec;
	}
    void puttime()
    {
    	cout<<"\nTime after addition : ";
    	cout<<hh<<" Hr "<<mm<<" Min "<<ss<<" Sec(s)"<<"\n";
	}
    friend time sum(time T1,time T2)
    {
    	time Temp;
		Temp.ss=T1.ss+T2.ss;
    	Temp.mm=T1.mm+T2.mm+Temp.ss/60;
    	Temp.hh=T1.hh+T2.hh+Temp.mm/60;
    	Temp.mm%=60;
    	Temp.ss%=60;
    	return Temp;
	}
};
int main()
{
    time T[2],T3,Temp;
    int hh,mm,ss;
    for(int i=0;i<2;i++)
    {
    	int j=i;
   		cout<<"Enter time "<<++j<<"\n";
  		cout<<"Hours : ";
		cin>>hh;
  		cout<<"Minutes : ";
		cin>>mm;
    	cout<<"Seconds : ";
		cin>>ss;
		cout<<"\n";
		T[i].gettime(hh,mm,ss);
	}
    Temp=sum(T[0],T[1]);
    Temp.puttime();
    return 0;
}
