// Made By Bhavya Popat, LAB Assignment 1, P2
#include<iostream>
using namespace std;
class Stud
{
	int r_no,marks,total;
	float percentage;
	char name[30];
	public:
	void compute(int cpp,int os,int sql,int bde,int eng)
	{
		total=cpp+os+sql+bde+eng;
		percentage=(float)total*100/(float)500;
	}
	void getinfo()
	{
		int cpp,os,sql,bde,eng;
		cout<<"Enter Roll Number : ";
		cin>>r_no;
		cout<<"Enter Name : ";
		cin>>name;
		cout<<"Enter C++ Marks : ";
		cin>>cpp;
		cout<<"Enter OS Marks : ";
		cin>>os;
		cout<<"Enter Oracle Marks : ";
		cin>>sql;
		cout<<"Enter BDE Marks : ";
		cin>>bde;
		cout<<"Enter English Marks : ";
		cin>>eng;
		compute(cpp,os,sql,bde,eng);
	}
	void putinfo()
	{
		cout<<"\nRoll. No : "<<r_no;
		cout<<"\nName : "<<name;
		cout<<"\nTotal Marks : "<<total;
		cout<<"\nPercentage : "<<percentage<<" %";
	}
};
int main()
{
	Stud s1;
	s1.getinfo();
	s1.putinfo();
	return 0;
}
