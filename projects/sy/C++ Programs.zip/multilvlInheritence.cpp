// Made By Bhavya Popat
#include<iostream>
using namespace std;
class linux
{
	public:
		void kernel()
		{
			cout<<"Linux Kernel\n";
		}
		void fileSystem()
		{
			cout<<"UNIX File System\n";
		}
};
class ubuntu : public linux
{
	public:
		void desktopEnv()
		{
			cout<<"GNOME\n";
		}
};
class lubuntu : public ubuntu
{
	public:
		void sysRequirements()
		{
			cout<<"System Requirements are lower than Ubuntu!\n";
		}
		void sizeOfOS()
		{
			cout<<"Size of OS is less than Ubuntu\n";
		}
		
};
int main()
{
	linux l;
	ubuntu u1;
	lubuntu l1;
	u1.kernel();
	u1.fileSystem();
	u1.desktopEnv();
	cout<<"\n";
	l1.sysRequirements();
	l1.sizeOfOS();
	l1.kernel();
	return 0;
}
