// Made By Bhavya Popat
#include<iostream>
using namespace std;
class Add
{
	public:
		int x,y,sum2;
		int *sum1=&sum2;
		int *pv=&x;
		int *pv1=&y;
		void getData(int x1,int y1)
		{
			x=x1;
			y=y1;
			sum();
		}
		void sum()
		{
			*sum1=*pv+*pv1;
		}
		void putdata()
		{
			cout<<*pv<<" + "<<*pv1<<" = "<<*sum1;
		}
};
int main()
{
	Add a1;
	int Add::*pv=&Add::x;
	int Add::*pv1=&Add::y;
	void (Add::*p)(int,int)=&Add::getData; (a1.*p) (10, 20);
	a1.putdata();
	return 0;
}
