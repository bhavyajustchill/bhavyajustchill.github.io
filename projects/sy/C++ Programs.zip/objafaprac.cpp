//Made by Bhavya Popat; E2 - 48
#include<iostream>
using namespace std;
class test
{
	int a,b;
	public:
	void getdata(int x,int y)
	{
		a=x;
		b=y;
	}
	void putdata()
	{
		cout<<a<<"\n";
		cout<<b<<"\n";
	}
	void add(test t1,test t2)
	{
		a=t1.a+t2.a;
		b=t1.b+t2.b;
	}	
};
int main()
{
	test t1,t2,t3;
	t1.getdata(10,5);
	t2.getdata(7,4);
	t3.add(t1,t2);
	t3.putdata();
	return 0;
}
