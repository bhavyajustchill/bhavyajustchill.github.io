// Made By Bhavya Popat
#include<iostream>
using namespace std;
class oprtr
{
	int a;
	public:
	void getData(int i)
	{
		a=i;
	}
	void operator <(oprtr m)
	{
		if(a<m.a)
		cout<<a<<" is less than "<<m.a;
		else
		cout<<m.a<<" is less than"<<a;
	}
};
int main()
{
	oprtr t1,t2;
	t1.getData(5);
	t2.getData(2);
	t1<t2;
	return 0;
}
