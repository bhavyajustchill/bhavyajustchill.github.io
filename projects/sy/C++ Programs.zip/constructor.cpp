// Made By Bhavya Popat
#include<iostream>
using namespace std;
class Test
{
	public:
		//constructor
		//same as class name
		//no return type, not even void
		//default constructor (no argument/parameter)
		//can be used for initialization
		//must always be public in order to access it
		Test()
		{
			cout<<"Bhavya";
		}
		Test(int a,int b) //parameterized constructor //this also signifies constructor overloading
		{
			cout<<"\n"<<a<<" + "<<b<<" = "<<a+b;
		}
};
int main()
{
	Test t1,t2(9,5);
	return 0;
}
