// Made by Bhavya Popat
#include<iostream>
using namespace std;
class Room
{
	int width, height; //public karvu pade direct value assign karva maate
	void setValue(int w, int h)
	{
		width=w;
		height=h;
	}
};
int main()
{
	Room objRoom;
	objRoom.width=12;
	return 0;
}
