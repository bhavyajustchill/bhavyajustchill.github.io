#include<iostream>
using namespace std;
enum days
{
	mon,tue,wed,thu=13,fri,sat,sun
};
int main()
{
	enum days d;
	for(int i=mon;i<=sun;i++)
	{
		cout<<ends<<i;
	}
	cout<<endl<<"Friday : "<<d;
	return 0;
}
