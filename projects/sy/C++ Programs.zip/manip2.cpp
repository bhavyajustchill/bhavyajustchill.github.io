// Code by Bhavya Popat, B.Sc. IT E2 [R.No. 48]
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int a=121,b=3000,c=42;
	double d=5.2345;
	cout<<setw(5)<<a<<endl;
	cout<<setw(5)<<b<<endl;
	cout<<setw(5)<<c<<endl;
	cout<<setw(5)<<setprecision(2)<<d<<endl;
	return 0;
}
