// Made by Bhavya Popat
#include<iostream>
using namespace std;
class dynamicOperator
{
	int *p;
	public:
	dynamicOperator()
	{
		p=new int;
		*p=5;
	}
	dynamicOperator(int i)
	{
		p=new int;
		*p=i;
	}
	void display()
	{
		cout<<*p<<"\n";
	}
};
int main()
{
	dynamicOperator t1,t2(10);
	t1.display();
	t2.display();
	return 0;
}
