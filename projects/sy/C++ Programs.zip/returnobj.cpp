//Made by Bhavya Popat; E2 - 48
#include<iostream>
using namespace std;
class complex
{
	int real,image;
	public:
	void getdata(int x,int y)
	{
		real=x;
		image=y;
	}
	void putdata()
	{
		cout<<"\n Addition : ";
		cout<<real<<" + ";
		cout<<image<<"i\n";
	}
	complex sum(complex t1,complex t2)
	{
		complex temp;
		temp.real=t1.real+t2.real;
		temp.image=t1.image+t2.image;
		return temp;
	}	
};
int main()
{
	int d1,d2;
	complex t1,t2,t3,temp;
	cout<<"Enter 1st Real & Imaginary Number : ";
	cin>>d1>>d2;
	t1.getdata(d1,d2);
	cout<<"Enter 2nd Real & Imaginary Number : ";
	cin>>d1>>d2;
	t2.getdata(d1,d2);
	temp=t3.sum(t1,t2);
	temp.putdata();
	return 0;
}
