//Made By Bhavya Popat
#include<iostream>
using namespace std;
class A
{
	public:
		void printLineA()
		{
			cout<<"This is from Class A";
		}
};
class B
{
	int i;
	public:
		void getB()
		{
			cout<<"\nEnter an Integer : ";
			cin>>i;
			cout<<"Integer Entered : "<<i;
		}
};
class C : public A, public B
{
	public:
		void putC()
		{
			cout<<"\nC is child of A and B";
		}
};
int main()
{
	C c1;
	c1.printLineA();
	c1.getB();
	c1.putC();
	return 0;
}
