//Made by Bhavya Popat
#include<iostream>
using namespace std;
class B;
class A
{
	int a;
	public:
	void getdata(int x)
	{
		a=x;
	}
	void putdata()
	{
		cout<<"A : "<<a<<"\n";
	}
	friend int sum(A,B);
};
class B
{
	int b;
	public:
	void getdata(int y)
	{
		b=y;
	}
	void putdata()
	{
		cout<<b;
		cout<<"B : "<<b<<"\n";
	}
	friend int sum(A,B);
};
int sum(A a1,B b1)
{
	return(a1.a+b1.b);
}
int main()
{
	A a1;
	B b1;
	a1.getdata(5);
	b1.getdata(6);
	cout<<sum(a1,b1);
	return 0;
}
