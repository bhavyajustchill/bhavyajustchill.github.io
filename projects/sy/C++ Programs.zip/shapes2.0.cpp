#include<iostream>
using namespace std;
class shape
{
	protected:
	double len,bre;
	public:
		int getData()
		{
			cout<<"Enter Length/Base : ";
			cin>>len;
			cout<<"Enter Height/Breadth : ";
			cin>>bre;
		}
		virtual void displayArea() = 0;
};
class triangle : public shape
{
	public:
	void displayArea()
	{
		double area;
		area=(0.5*len*bre);
		cout<<"\nArea of Triangle : "<<area;
	}
};
class rectangle : public shape
{
	public:
	void displayArea()
	{
		double area;
		area=(len*bre);
		cout<<"\nArea of Rectangle : "<<area;
	}
};
int main()
{
	triangle t1;
	rectangle r1;
	cout<<"For Triangle...\n";
	t1.getData();
	cout<<"For Rectangle...\n";
	r1.getData();
	r1.displayArea();
	t1.displayArea();
	return 0;
}
