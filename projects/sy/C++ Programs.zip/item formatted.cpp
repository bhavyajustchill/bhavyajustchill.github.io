//Program by Bhavya Popat, E2 - 48
#include<iostream>
#include<iomanip>
using namespace std;
class item
{
	public:
	int item_no;
	float item_cost;
	void getdata()
	{
		cout<<"Enter Item No. : ";
		cin>>item_no;
		cout<<"Enter Item Cost : ";
		cin>>item_cost;
		cout<<"\n";
	}
	void putdata();
	
};
void item::putdata()
{	
	cout<<"\nItem No. : "<<item_no;
	cout<<"\nItem Cost : Rs. "<<item_cost;
	cout<<"\n\n";
}
int main()
{
	class item i[100];
	int n;
	cout<<"Enter no. of items : ";
	cin>>n;
	for(int j=0;j<n;j++)
	{
		i[j].getdata();
	}
	for(int k=0;k<n;k++)
	{
		i[k].putdata();
	}
	return 0;
}
