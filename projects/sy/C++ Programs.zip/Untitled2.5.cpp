//Code by Bhavya Popat, B.Sc. IT - E2 [48]
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	float *b=new float[5];
	float sum=0;
	double avg;
	cout<<"Enter 5 Values : ";
	for(int i=0;i<5;i++)
	{
		cin>>b[i];
		sum=sum+b[i];
	}
	avg=sum/5;
	cout<<"=====================";
	cout<<"\nSum : \t\t"<<setw(3)<<sum;
	cout<<"\nAverage : \t"<<setw(3)<<setprecision(4)<<avg;
	delete b;
	return 0;
}
