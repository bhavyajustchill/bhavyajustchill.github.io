//Made By Bhavya Popat
#include<iostream>
using namespace std;
class A
{
	protected:
	int i;
};
class B : public A
{
	public:
		void getData()
		{
			cout<<"Enter an Integer : ";
			cin>>i;
		}
		void putData()
		{
			cout<<"Integer : "<<i;
		}
};
int main()
{
	B b;
	b.getData();
	b.putData();
	return 0;
}
