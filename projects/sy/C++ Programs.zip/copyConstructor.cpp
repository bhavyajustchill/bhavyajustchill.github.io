// Made By Bhavya Popat
#include<iostream>
using namespace std;
class constructor
{
	int a,b;
	public:
	constructor() {} // Default Constructor
	constructor(int x,int y)
	{
		a=x;
		b=y;
	}
	constructor(constructor &obj)
	{
		a=obj.a;
		b=obj.b;
	}
	void print()
	{
		cout<<a<<" "<<b<<"\n";
	}
};
int main()
{
	constructor t1(5,10);
	constructor t2(t1);
	constructor t3=t2;
	constructor t4;
	t4=t3;
	t1.print();
	t2.print();
	t3.print();
	t4.print();
	return 0;
}
