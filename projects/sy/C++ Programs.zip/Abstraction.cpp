//Made By Bhavya Popat
#include<iostream>
using namespace std;
class Phone
{
	public:
		virtual void call()=0;
		virtual void sms()=0;
		virtual void fly()=0;
		virtual void swim()=0;
};
class Utsav : public Phone
{
	public:
		void call()
		{
			cout<<"Calling Available!";
		}
		void sms()
		{
			cout<"\nSMS Available!";
		}
};
class Bhavya : public Utsav
{
	public:
		void fly()
		{
			cout<<"\nYou can throw your phone and it won't be damaged!";
		}
};
class Manas : public Bhavya
{
	public:
		void swim()
		{
			cout<<"\nPhone is Waterproof!";
		}
};
int main()
{
	Manas m;
	Phone *p=&m;
	p->call();
	p->sms();
	p->fly();
	p->swim();
	return 0;
}
