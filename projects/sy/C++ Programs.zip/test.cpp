//Program by Bhavya Popat, E2 - 48
#include<iostream>
#include<iomanip>
using namespace std;
class bank_account
{
	char depositer[30];
	float balance_amt,acc_type;
	public:
	int getdata()
	{
		int type;
		cout<<"Enter Depositer Name : ";
		cin>>depositer;
		cout<<"1. Savings Account"<<"\n"<<"2. Current Account"<<"\n"<<"3. Salary Account"<<"\n"<<"4. Kids Account";
		cout<<"\nEnter Type of Account : ";
		cin>>type;
		acc_type=type;
	}
	void deposit()
	{
		balance_amt=0;
		float money_d;
		cout<<"Enter Amount to deposit : ";
		cin>>money_d;
		balance_amt=balance_amt+money_d;
	}
	void withdraw()
	{
		float money_w;
		cout<<"Enter Amount to Withdraw : ";
		cin>>money_w;
		balance_amt=balance_amt-money_w;
	}
	void putdata()
	{
		cout<<"\nName of Depositor : \t\t"<<depositer;
		cout<<"\nCurrent Balance : \t\t"<<setw(8)<<setprecision(3)<<balance_amt<<endl;
		if(acc_type==1)
		{
			cout<<"You have A Savings Account";
		}
		else if(acc_type==2)
		{
			cout<<"You have A Current Account";
		}
		else if(acc_type==3)
		{
			cout<<"You have A Salary Account";
		}
		else if(acc_type==4)
		{
			cout<<"You have A Kids Account";
		}
		cout<<"\n";
	}
};
int main()
{
	class bank_account mem[100];
	int n;
	cout<<"Enter No. of Account Holders : ";
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cout<<"\n\nAccount Holder No. "<<i<<"\n";	
		mem[i].getdata();
		mem[i].deposit();
		mem[i].withdraw();
	}
	for(int j=1;j<=n;j++)
	{
		cout<<"\n\nAccount Holder No. "<<j<<"\n";
		mem[j].putdata();
	}
	return 0;
}
