//Program by Bhavya Popat, E2 - 48
#include<iostream>
#include<iomanip>
using namespace std;
class box
{
	public:
	float l,b,h;
	void volume(float l,float b, float h)
	{
		float vol;
		vol=l*b*h;
		cout<<"\n=========================================\n";
		cout<<"Volume of Box : \t\t"<<setw(5)<<setprecision(4)<<vol;
	}
};
void getdata();
int main()
{
	class box a;
	getdata();
	return 0;
}
void getdata()
{
	char ch;
	class box a;
	cout<<"Enter L : ";
	cin>>a.l;
	cout<<"Enter B : ";
	cin>>a.b;
	cout<<"Enter H : ";
	cin>>a.h;
	while(1)
	{
		cout<<"\nDo you want Volume? [Press Y/N] : ";
		cin>>ch;
		switch(ch)
		{
			case 'y': 
			case 'Y':
				a.volume(a.l,a.b,a.h);
				break;
			case 'n':
			case 'N':
				cout<<"\nOkay, Thank you! Press any key to exit!";
				break;
			default:
				cout<<"Choose Appropriate choice!\n";
		}
		if(ch=='n' || ch=='N')
		break;
	}
}
