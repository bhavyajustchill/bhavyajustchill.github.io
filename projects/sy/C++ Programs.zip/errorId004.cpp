// Made By Bhavya Popat
#include<iostream>
using namespace std;
class Room
{
	int length;
	int width;
	public:
	Room(int l,int w=0):
		width(w),
		length(l)
		{
		}	
};
int main()
{
	Room objRoom1;
	Room objRoom2(12,8);
	return 0;
}
