#include<iostream>
using namespace std;
void swap(int &x,int &y)
{
	int temp;
	temp=x;
	x=y;
	y=temp;
}
int main()
{
	int a,b;
	cout<<"Enter A : ";
	cin>>a;
	cout<<"Enter B : ";
	cin>>b;
	swap(a,b);
	cout<<"After Swapping..\n";
	cout<<"A : "<<a<<endl;
	cout<<"B : "<<b;
	return 0;
}

