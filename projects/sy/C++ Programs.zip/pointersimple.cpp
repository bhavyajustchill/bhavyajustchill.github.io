// Made By Bhavya Popat
#include<iostream>
using namespace std;
class A
{
	public:
		int x;
		void getdata(int i)
		{
			x=i;
		}
};
int main()
{
	A a1;
	A *p;
	p=&a1;
	a1.getdata(5);
	cout<<a1.x<<"\n";
	cout<<p->x;
	return 0;
}
