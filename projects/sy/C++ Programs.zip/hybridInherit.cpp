//Made By Bhavya Popat
#include<iostream>
using namespace std;
class A
{
	public:
		void putA()
		{
			cout<<"\nA";
		}
};
class B : virtual public A   //Virtual is used when single copy of a function is there in GrandParent
{
	public:
		void putB()
		{
			cout<<"\nB";
		}
};
class C : virtual public A
{
	public:
		void putC()
		{
			cout<<"\nC";
		}
};
class D : public B, public C
{
	public:
		void putD()
		{
			cout<<"\nD";
		}
};
int main()
{
	D d1;
	d1.putD();
	d1.putC();
	d1.putB();
	d1.putA();
	return 0;
}
