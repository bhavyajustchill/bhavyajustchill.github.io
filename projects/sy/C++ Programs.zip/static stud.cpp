#include<iostream>
#include<iomanip>
using namespace std;
static int rno;
static int count;
class student
{
	int rno1,count1;
	char nm[30];
	int marks;
	public:
	void getdata()
	{
		count++;
		rno++;
		cout<<"Roll No. "<<rno;
		cout<<"\nEnter Name : ";
		cin>>nm;
		cout<<"Enter C++ Marks : ";
		cin>>marks;
		rno1=rno;
		count1=count;
	}
	void putdata()
	{
		cout<<"\n\nRoll. No. : "<<rno1;
		cout<<"\nName : "<<nm;
		cout<<"\nC++ Marks : ";
		cout<<"\nAttendence : "<<count1;
	}
};
int main()
{
	class student s[10];
	int n,i;
	cout<<"Enter No. of Students : ";
	cin>>n;
	for(i=0;i<n;i++)
	{
		s[i].getdata();
	}
	for(i=0;i<n;i++)
	{
		s[i].putdata();
	}
	return 0;
}
