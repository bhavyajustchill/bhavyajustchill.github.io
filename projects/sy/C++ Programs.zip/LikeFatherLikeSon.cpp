//Made By Bhavya Popat
#include<iostream>
using namespace std;
class Father
{
	public:
	float height=183.25;
	char color[5]="Fair";
	friend class Mother;
};
class Mother
{
	public:
	char eyeColor[5]="Blue";
};
class Child : public Father, virtual public Mother
{};
int main()
{
	Child ch;
	cout<<"Child's Complexion of Skin : "<<ch.color;
	cout<<"\nChild's Eye Color : "<<ch.eyeColor;
	cout<<"\nChild's Height : "<<ch.height<<" cm";
	return 0;
}
