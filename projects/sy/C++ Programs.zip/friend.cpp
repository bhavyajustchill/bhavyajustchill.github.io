// Made by Bhavya Popat, B.Sc IT E2 (48)
#include<iostream>
using namespace std;
class test1
{
		int a;
		public:
			void getdata(int x)
			{
				a=x;
			}
			
			friend void putdata(test1); // not a class member
};
void putdata(test1 c)
{
	cout<<c.a;
}
int main()
{
	test1 t1;
	t1.getdata(10);
	putdata(t1);
	return 0;
}
