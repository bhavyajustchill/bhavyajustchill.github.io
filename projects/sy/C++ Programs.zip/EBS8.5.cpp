//Made by Bhavya Popat
#include<iostream>
using namespace std;
class Master
{
	char name[20];
	int code;
	public:
		void getInfo()
		{
			cout<<"\nEnter Name : ";
			cin>>name;
			cout<<"Enter Code : ";
			cin>>code;
		}
		void putInfo()
		{
			cout<<"\nName : "<<name;
			cout<<"\nCode : "<<code;
		}
};
class Account : virtual public Master
{
	int pay;
	public:
		void getPay()
		{
			cout<<"Enter Payment : ";
			cin>>pay;
		}
		void putPay()
		{
			cout<<"\nPayment : Rs. "<<pay;
		}
};
class Admin : virtual public Master
{
	int experience;
	public:
		void getExperience()
		{
			cout<<"Enter Experience (in Years) : ";
			cin>>experience;
		}
		void putExperience()
		{
			cout<<"\nExperience : "<<experience<<" year(s)";
		}
};
class Person : public Admin, public Account
{};
int main()
{
	Person p1;
	p1.getInfo();
	p1.getPay();
	p1.getExperience();
	p1.putInfo();
	p1.putPay();
	p1.putExperience();
	return 0;
}
