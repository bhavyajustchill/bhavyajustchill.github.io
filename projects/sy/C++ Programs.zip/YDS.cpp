//Made By Bhavya
#include<iostream>
using namespace std;
class YDS
{
	int students,year;
	public:
		void putInfo()
		{
			cout<<"\nYDS stands for YOGI DIVINE SOCIETY";
		}
		void getData()
		{
			cout<<"\nEnter No. of Students : ";
			cin>>students;
			cout<<"Enter the Year Established : ";
			cin>>year;
		}
		void putData()
		{
			cout<<"\nNo. of Students : ";
			cout<<"\nYear Established "<<year;
		}
};
class Virani : virtual public YDS
{};
class AITS : virtual public YDS
{};
int main()
{
	Virani vsc;
	AITS au;
	cout<<"Enter Details of Virani\n";
	vsc.getData();
	cout<<"\n\nEnter Details of Atmiya\n";
	au.getData();
	cout<<"\nDetails of Virani\n";
	vsc.putData();
	cout<<"\n\n\nDetails of Atmiya\n";
	au.putData();
	cout<<"\n";
	au.putInfo();
	return 0;
}
