// Made By Bhavya Popat
#include<iostream>
using namespace std;
class A
{
	public:
		int x;
		int *pv=&x;
		void putdata()
		{
			cout<<*pv;
		}
};
int main()
{
	A a1;
	int A::*pv=&A::x;
	a1.*pv=10;
	a1.putdata();
	return 0;
}
