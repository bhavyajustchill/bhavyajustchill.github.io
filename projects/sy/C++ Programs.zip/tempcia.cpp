#include<iostream>
using namespace std;
enum test{A=11,B,C,D};
int main()
{
	cout<<A<<B<<C<<D;
	return 0;
}
