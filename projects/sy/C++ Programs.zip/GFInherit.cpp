// Made By Bhavya PPopat
#include<iostream>
using namespace std;
class GF
{
	int height;
	char color[15];
	public:
	void getInfo()
	{
		cout<<"Enter Height : ";
		cin>>height;
		cout<<"Enter Colour : ";
		cin>>color;
	}
	void putInfo()
	{
		cout<<"\nHeight : "<<height<<" cm";
		cout<<"\nColor : "<<color;
	}
};
class F : public GF
{
	char eyecolor[15];
	public:
	void getData()
	{
		cout<<"Enter Eye Colour : ";
		cin>>eyecolor;
	}
	void putData()
	{
		cout<<"\nEye Colour : "<<eyecolor;	
	}	
};
class Son : public F
{};
int main()
{
	GF gf1;
	F f1;
	Son s1;
	s1.getInfo();
	s1.getData();
	s1.putInfo();
	s1.putData();
	return 0;
}
