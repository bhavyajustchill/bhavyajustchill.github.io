// Made By Bhavya Popat
#include<iostream>
using namespace std;
class STAFF
{
	int code;
	char name[30];
	public:
		void getInfo()
		{
			cout<<"Enter Code : ";
			cin>>code;
			cout<<"Enter Name : ";
			cin>>name;
		}
		void putInfo()
		{
			cout<<"\nCode : "<<code;
			cout<<"\nName : "<<name;
		}
};
class Teacher : public STAFF
{
	char subject[10],publication[15];
	public:
		void getSub()
		{
			cout<<"Enter Teacher's Subject : ";
			cin>>subject;
			cout<<"Enter Teacher's Publication : ";
			cin>>publication;
		}
		void putSub()
		{
			cout<<"\nTeacher's Subject : "<<subject;
			cout<<"\nTeacher's Publication : "<<publication;
		}
};
class Typist : public STAFF
{
	int speed;
	public:
		void getSpeed()
		{
			cout<<"Enter Typist's Speed : ";
			cin>>speed;
		}
		void putSpeed()
		{
			cout<<"\nTypist Speed : "<<speed<<" wpm";
		}
};
class Officer : public STAFF
{
	char grade[15];
	public:
		void getGrade()
		{
			cout<<"Enter Officer's Grade : ";
			cin>>grade;
		}
		void putGrade()
		{
			cout<<"\nOfficer Grade : "<<grade;
		}
};
class regular : public Typist
{};
class casual : public Typist
{
	int daily_wages;
	public:
		void getWage()
		{
			cout<<"Enter Typist's Daily Wages : ";
			cin>>daily_wages;
		}
		void putWage()
		{
			cout<<"\nTypist's Daily Wage : Rs. "<<daily_wages;
		}
};
int main()
{
	STAFF s1,s2,s3;
	Teacher t1;
	Typist ty1;
	Officer o1;
	regular r1;
	casual c1;
	cout<<"Enter Data of Typist\n";
	c1.getInfo();
	c1.getSpeed();
	c1.getWage();
	cout<<"\nEnter Data of Teacher\n";
	t1.getInfo();
	t1.getSub();
	cout<<"\nEnter Data of Officer\n";
	o1.getInfo();
	o1.getGrade();
	cout<<"\n\nData of Teacher\n";
	t1.putInfo();
	t1.putSub();
	cout<<"\n\nData of Typist\n";
	c1.putInfo();
	c1.putSpeed();
	c1.putWage();
	cout<<"\n\nData of Officer\n";
	o1.putInfo();
	o1.putGrade();
	return 0;
}
