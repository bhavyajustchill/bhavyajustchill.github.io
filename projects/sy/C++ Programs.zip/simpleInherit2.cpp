// Made By Bhavya Popat
#include<iostream>
using namespace std;
class linux
{
	public:
		void kernel()
		{
			cout<<"Linux Kernel\n";
		}
		void fileSystem()
		{
			cout<<"UNIX File System\n";
		}
};
class ubuntu : private linux
{
	public:
		void desktopEnv()
		{
			kernel();
			cout<<"GNOME\n";
		}
};
int main()
{
	linux l;
	ubuntu u1;
	u1.kernel();
	u1.fileSystem();
	u1.desktopEnv();
	return 0;
}
