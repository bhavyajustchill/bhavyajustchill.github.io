// Made By Bhavya Popat
#include<iostream>
using namespace std;
class test
{
	public:
		test()
		{
			cout<<"Constructor\n";
		}
		~test()
		{
			cout<<"Destructor\n";
		}
};
int main()
{
	test t1,t2;
	{
		cout<<"1st Block\n";
		test t3;
	}
	{
		cout<<"2nd Block\n";
		test t4;
	}
	cout<<"main function\n";
	return 0;
}
