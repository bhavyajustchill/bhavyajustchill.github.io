#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;
static int rno;
static int count;
class student
{
	int rno1,count1;
	char nm[30];
	int marks;
	public:
	void putdata()
	{
		cout<<"\n\nRoll. No. : "<<rno1;
		cout<<"\nName : "<<nm;
		cout<<"\nC++ Marks : ";
		cout<<"\nAttendence : "<<count1;
	}
};
int main()
{
	ifstream fin;
	class student s[3];
	int n=2,i=0;
	fin.open("Students.txt");
	fin.read((char *)&s[i],sizeof(s[i]));
	for(i=1;i<=n;i++)
	{
		fin.read((char *)&s[i],sizeof(s[i]));
		s[i].putdata();
	}
	return 0;
}
