// Program by Bhavya Popat, E2 -48
#include<iostream>
using namespace std;
class abc
{
	//by default pvt
	//class name
	//variables
	public:  //below public data is public
		int x=getdata();
	//functions
	void getdata(int data)
	{
		cin>>data;
		x=data;	
	}
};
int main()
{
	class abc a; //objects
	a.getdata();
	cout<<a.x<<"\n"<<b.x;
	return 0;
}
