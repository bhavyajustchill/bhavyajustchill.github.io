// Made By Bhavya Popat
#include<iostream>
using namespace std;
class time
{
	int hh,mm,ss;
	public:
		time(int hr,int min,int sec)
		{
			hh=hr;
			mm=min;
			ss=sec;
		}
		time(time &t2)
		{
			hh=t2.hh;
			mm=t2.mm;
			ss=t2.ss;
		}
		void puttime()
		{
			cout<<hh<<" Hr "<<mm<<" Min "<<ss<<" Sec\n";
		}
};
int main()
{
	int hr,min,sec;
	cout<<"Enter Hr, Min and Sec : ";
	cin>>hr>>min>>sec;
	time t1(hr,min,sec);
	time t2=t1;
	cout<<"\nDefault Constructor :\n";
	t1.puttime();
	cout<<"\nCopy Constructor : \n";
	t2.puttime();
	return 0;
}
