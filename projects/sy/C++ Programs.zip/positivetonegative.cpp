// Made By Bhavya Popat
#include<iostream>
using namespace std;
class alter
{
	int chg,chg1,chg2,temp,temp1,temp2;
	public:
		alter()
		{
			
		}
		alter(int i,int j,int k)
		{
			temp=i;
			temp1=j;
			temp2=k;
		}
		alter operator-(alter);
		void display()
		{
			cout<<chg<<"\n"<<chg1<<"\n"<<chg2;
		}
};
alter alter::operator-(alter A1)
{
	chg=A1.temp-(2*A1.temp);
	chg1=A1.temp1-(2*A1.temp1);
	chg2=A1.temp2-(2*A1.temp2);
}
int main()
{
	int i,j,k;
	cout<<"Enter three Numbers : ";
	cin>>i>>j>>k;
	alter A1(i,j,k);
	alter A2;
	A2.operator-(A1);
	A2.display();
	return 0;
}
