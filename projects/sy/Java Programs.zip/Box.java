class Box
{
	int height,width,depth,volume;
	Box(int h,int w,int d)
	{
		height=h;
		width=w;
		depth=d;
	}
	void calc()
	{
		volume=height*width*depth;
	}
	void display()
	{
		System.out.println(volume);
	}
	public static void main(String[] args)
	{
		Box b1 = new Box(10,10,10); // constructor dynamically allocated
		/*b1.height=10;
		b1.width=10;
		b1.depth=10;*/
		b1.calc();
		b1.display();
	}
}