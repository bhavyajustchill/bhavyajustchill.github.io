class A
{
	int x=1;
}
class B extends A
{
	int x=2;
	void display(int x)
	{
		System.out.println(x); // local variable
		System.out.println(this.x); // class variable
		System.out.println(super.x); // parent class variable
	}
}
class VarLife
{
	public static void main(String[] args)
	{
		B b1 = new B();
		b1.display(3);
	}
}