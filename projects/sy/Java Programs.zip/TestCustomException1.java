class MyException extends RuntimeException
{  
        MyException(String str1)
	{  
      		super(str1);  
     	}  
}  
class ExceptionDemo
{
       static void compute(int x)throws MyException
       {  
         	if(x>10)  
          	throw new InvalidAgeException(x+" is Not Valid as it is greater than 10");  
         	else  
         	System.out.println("X : "+x);  
       }   
       public static void main(String args[])
       {  
          try
	  {  
          	compute(14);  
          }
	  catch(Exception e1)
	  {
		System.out.println("Exception occured: "+e1);
	  }   
      }  
}  