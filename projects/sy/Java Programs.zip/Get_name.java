import java.util.Scanner;
class Get_name
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name : ");
		System.out.println(sc.nextLine());
		// sc.next() => String till space is read
	}
}