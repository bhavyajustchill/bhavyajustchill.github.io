class TestThread extends Thread
{
	public void run()
	{
		try
		{
			for(int i=0;i<3;i++)
			{
				Thread.sleep(2000);
				System.out.println(i+1);
			}
		}
		catch(InterruptedException e1)
		{
			System.out.println(e1);
		}
	}
}
class Thread2
{
	public static void main(String args[])
	{
		TestThread t1 = new TestThread();
		t1.start();
	}
}