class Animal
{
	void eating()
	{
		System.out.println("Eating");
	}
	void sleeping()
	{
		System.out.println("Sleeping");
	}
}
class Dog extends Animal // Inheritance
{
	void barking()
	{
		System.out.println("Barking");
	}
	public static void main(String[] args)
	{
		Dog d = new Dog();
		d.eating();
		d.sleeping();
		d.barking();
	}
}