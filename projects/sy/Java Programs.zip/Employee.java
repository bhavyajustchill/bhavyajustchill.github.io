class Employee
{
	String emp_name;
	int emp_id;
	void getData(String nm, int id)
	{
		emp_name=nm;
		emp_id=id;
	}
	void putData()
	{
		System.out.print("Employee ID : ");
		System.out.println(emp_id);
		System.out.print("Employee Name : ");
		System.out.println(emp_name);
		System.out.println();
	}
	public static void main(String[] args)
	{
		Employee e1 = new Employee();
		e1.getData("abc",1);
		e1.putData();
		Employee e2 = new Employee();
		e2.getData("xyz",2);
		e2.putData();
	}
}