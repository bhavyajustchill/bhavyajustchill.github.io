import java.util.Random;
public class Dice
{
	public static void main(String[] args)
	{
		int x;
		Random r1 = new Random();
		x=r1.nextInt(6)+1;
		System.out.println("Dice Number : "+x);
	}	
}