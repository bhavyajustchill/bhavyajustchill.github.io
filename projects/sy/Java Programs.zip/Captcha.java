import java.util.Scanner;
import java.util.Random;
public class Captcha
{
	public static void main(String[] args)
	{
		char[] str4={1,2,3,4,5,6};
		String str1="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		Scanner sc = new Scanner(System.in);
		Random r1 = new Random();
		System.out.print("Captcha : ");
		for(int k=0;k<6;k++)
		{	
			char str2=str1.charAt(r1.nextInt(str1.length()));
			System.out.print(str2);
			str4[k]=str2;
		}
		String str5 = String.valueOf(str4);
		System.out.println();
		System.out.print("Enter your answer : ");
		String str3=sc.next();
		if(str3.equals(str5))
		{
			System.out.println("Captcha is Correct!");
		}
		else
		{
			System.out.println("Captcha is Incorrect!");
		}
	}	
}