abstract class Shape
{
	abstract void area();
}
class Rectangle extends Shape
{
	int l=5,b=3,ans;
	void area()
	{
		ans=l*b;
		System.out.println("Area of Rectangle : "+ans);
	}
}
class Circle extends Shape
{
	double ans,r=14;
	void area()
	{
		ans=3.14*r*r;
		System.out.println("Area of Circle : "+ans);
	}
}
class ShapeAbs
{
	public static void main(String[] args)
	{
		Rectangle r = new Rectangle();
		Circle c = new Circle();
		r.area();
		c.area();
	}
}