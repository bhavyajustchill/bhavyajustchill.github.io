class FirstThread extends Thread
{
	public void run() // invokes when used obj.start()
	{
		for(int i=0; i<10; i++)
		{
			System.out.println("Child 1");
		}
	}
}
class SecondThread extends Thread
{
	public void run()
	{
		for(int i=0; i<10; i++)
		{
			System.out.println("Child 2");
		}
	}
}
class ThreadDemo
{
	public static void main(String[] args)
	{
		FirstThread t1 = new FirstThread();
		SecondThread t2 = new SecondThread();
		t1.start();
		t2.start();
		for(int i=0; i<10; i++)
		{
			System.out.println("main");
		}
	}
}