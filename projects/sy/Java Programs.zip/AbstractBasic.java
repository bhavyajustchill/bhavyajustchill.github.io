abstract class A
{
	abstract void display();
}
class B extends A
{
	void display()
	{
		System.out.println("Abstraction!");
	}
}
class AbstractBasic
{
	public static void main(String[] args)
	{
		B b1 = new B();
		b1.display();
	}
}