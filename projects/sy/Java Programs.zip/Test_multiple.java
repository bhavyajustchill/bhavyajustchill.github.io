/* create two interface Printable and Showable having methods print() and show() respectively. Create a Test_multiple class which implements all two interfaces and override print() and show() methods. write a main method in this class and create an object of this class and use method*/
interface Printable
{
	void print();
}
interface Showable
{
	void show();
}
class Test_multiple implements Printable,Showable
{
	public void print()
	{
		System.out.println("Printable!");
	}
	public void show()
	{
		System.out.println("Showable!");
	}
	public static void main(String[] args)
	{
		Test_multiple tm1 = new Test_multiple();
		tm1.print();
		tm1.show();
	}
}