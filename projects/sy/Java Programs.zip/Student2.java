import java.util.Scanner;
class Student2
{
	String stu_name;
	int roll_no;
	void getData(int x, String y)
	{
		stu_name=y;
		roll_no=x;
	}
	void putData()
	{
		System.out.println("Name : "+stu_name);
		System.out.println("Roll No. : "+roll_no);
	}
	public static void main(String[] args)
	{
		String n;
		int r;
		Student2 s1 = new Student2();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name");
		n=sc.nextLine();
		System.out.println("Enter Roll No.");
		r=sc.nextInt();
		s1.getData(r,n);
		s1.putData();
	}
}
