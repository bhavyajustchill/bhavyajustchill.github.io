package com.ibm.bank.loan;
import com.tcs.bank.loan.Test;
class Demo2
{
	public static void main(String[] args)
	{
		Test t = new Test();
		System.out.println("Good Morning!");
	}
}