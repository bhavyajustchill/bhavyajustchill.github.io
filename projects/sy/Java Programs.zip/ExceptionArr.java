/*
Declare an array with two elements. Try to access third element as [arr[3] = 30/0;].
*/
class ExceptionArr
{
	public static void main(String[] args)
	{
		int[] arr={1,2};
		
		System.out.println(arr[3]);
		try
		{
			arr[3]=30/0;
			System.out.println(arr[3]);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Bhavya!");
		}
		catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.println("Popat!");
		}
	}
}