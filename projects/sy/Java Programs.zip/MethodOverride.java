class A
{
	void test()
	{
		System.out.println("Class A");
	}
}
class B
{
	void test() // if same function exists in child class, it has more priority
	{
		System.out.println("Class B");
	}
}
class MethodOverride
{
	public static void main(String[] args)
	{
		B b1 = new B();
		b1.test();
	}
}