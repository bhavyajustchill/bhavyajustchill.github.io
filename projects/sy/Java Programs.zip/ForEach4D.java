class ForEach4D
{
	public static void main(String[] args)
	{
		int[][][][] a={{{{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15},{16,17,18,19,20}}}};
		for(int[][][] a1:a)
		{
			for(int[][] a2:a1)
			{
				for(int[] a3:a2)
				{
					for(int a4:a3)
					{
						System.out.println(a4);
					}
				}
			}
		}
	}
}