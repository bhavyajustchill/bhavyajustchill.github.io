class ExceptionTest
{
	static void a()
	{
		b();
	}
	static void b()
	{
		System.out.println("Hello!");
		try
		{
			System.out.println(10/0);
		}
		// System.out.println("hi!"); // program wont detect catch if printed in between
		catch(Exception e) /*program won't compile with only try block and in absencee of catch block*/
		{
			System.out.println(10/2);
		} 
		System.out.println("Good Morning!");
	}
	public static void main(String[] args)
	{
		a();
	}
}