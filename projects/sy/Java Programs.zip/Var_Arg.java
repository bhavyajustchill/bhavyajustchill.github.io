class Var_Arg
{
	void test(int... a)
	{
		
		for(int a1:a)
		{
			System.out.println(a1);
		}
	}
	public static void main(String[] args)
	{
		Var_Arg v = new Var_Arg();
		v.test(10,20,30);
		v.test(10,20);
	}

}