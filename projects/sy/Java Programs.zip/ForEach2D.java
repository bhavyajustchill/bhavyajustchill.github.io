class ForEach2D
{
	public static void main(String[] args)
	{
		int a[][]={{1,2,3,4,5},{6,7,8,9,10}};
		for(int[] a1:a)
		{
			for(int a2:a1)
			{
				System.out.println(a2);
			}
		}
	}
}