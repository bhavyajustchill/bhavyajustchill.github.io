/*Write a program to perform mathematical operation. Create a class called AddSub with attributes num1 and num2 of type int. Also define methods calAdd() and calSub() to calculate Addition and Subtraction. Create another class MulDiv that extends AddSub class to use member data of super class. MulDiv should have methods calMul() and calDiv() to calculate multiplication and division. A main method should aceess methods and perform operations.*/
class AddSub
{
	int num1=10,num2=5,ans;
	void calAdd()
	{
		ans=num1+num2;
		System.out.println("Addition : "+ans);
	}
	void calSub()
	{
		ans=num1-num2;
		System.out.println("Subtraction : "+ans);
	}
}
class MulDiv extends AddSub
{
	void calMul()
	{
		super.ans=super.num1*super.num2;
		System.out.println("Multiplication : "+ans);
	}
	void calDiv()
	{
		super.ans=super.num1/super.num2;
		System.out.println("Division : "+ans);
	}
}
class Calc
{
	public static void main(String[] args)
	{
		MulDiv x = new MulDiv();
		x.calAdd();
		x.calSub();
		x.calMul();
		x.calDiv();
	}
}