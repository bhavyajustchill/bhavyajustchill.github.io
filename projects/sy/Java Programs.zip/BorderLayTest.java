import java.applet.*;
import java.awt.*;
//<applet code=BorderLayTest width=400 height=400> </applet>

public class BorderLayTest extends Applet
{
	public void init()
	{
		setLayout(new BorderLayout());
		Button b1 = new Button("North");
		Button b2 = new Button("South");
		Button b3 = new Button("East");
		Button b4 = new Button("West");
		Button b5 = new Button("Center");
		add(b1,BorderLayout.NORTH);
		add(b2,BorderLayout.SOUTH);
		add(b3,BorderLayout.EAST);
		add(b4,BorderLayout.WEST);
		add(b5,BorderLayout.CENTER);
	}
}