import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

//<applet code=ActionDemo width=400 height=400> </applet>

public class ActionDemo extends Applet implements ActionListener
{
	TextField tf1;
	public void init()
	{
		Button b1 = new Button("Red");
		Button b2 = new Button("Green");
		Button b3 = new Button("Blue");
		tf1 = new TextField(14);
		add(b1);
		add(b2);
		add(b3);
		add(tf1);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String s = ae.getActionCommand();
		tf1.setText(s);
		if(s.equals("Red"))
		{
			setBackground(Color.RED);
		}
		else if(s.equals("Green"))
		{
			setBackground(Color.GREEN);
		}
		else
		{
			setBackground(Color.BLUE);
		}
	}
}