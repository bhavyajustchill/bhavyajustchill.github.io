import java.util.Scanner;
class Scan_sum
{
	public static void main(String[] args)
	{
		int a,b,sum;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 Integers");
		a=sc.nextInt();
		b=sc.nextInt();
		sum=a+b;
		System.out.println("Sum : "+sum);
	}
}