import java.util.Scanner;
class MyException extends RuntimeException
{  
        MyException(String str1)
	{  
      		super(str1);  
     	}  
}  
class ExceptionDemo
{
       static void compute(int x)throws MyException
       {  
         	if(x>10)  
          	throw new MyException(x+" is Not Valid as it is greater than 10");  
         	else  
         	System.out.println("X : "+x);  
       }   
       public static void main(String args[])
       {  
	  int x;
	  Scanner sc = new Scanner(System.in);
	  System.out.print("Enter an Integer : ");
	  x=sc.nextInt();
          try
	  {  
          	compute(x);  
          }
	  catch(Exception e1)
	  {
		System.out.println("Exception occured: "+e1);
	  }   
      }  
}  