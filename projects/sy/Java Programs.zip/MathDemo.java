/*
Create a package mathpack having class MathDemo with method add() and sub() to find addition and subtraction. Create another program and import package and invoke methods.
*/
package mathpack;
public class MathDemo
{
	public void add(int x,int y)
	{
		int ans;
		ans=x+y;
		System.out.println("Sum : "+ans);
	}
	public void sub(int x,int y)
	{
		int ans;
		ans=x-y;
		System.out.println("Difference : "+ans);
	}
}	