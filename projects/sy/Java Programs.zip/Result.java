class Result
{
	//void fun(int... b, String a) ---> error: varargs parameter must be the last parameter
	void fun(String a, int... b)
	{
		int count=0,total=0,per;
		for(int b1:b)
		{
			count++;
			total=total+b1;
		}
		per=(total*100)/(100*count);
		System.out.print("Name : ");
		System.out.println(a);
		System.out.print("Total Subjects : ");
		System.out.println(count);
		System.out.print("Total Marks : ");
		System.out.println(total);
		System.out.print("Percentage : ");
		System.out.print(per);
		System.out.print(" %");
	}
	public static void main(String[] args)
	{
		Result r = new Result();
		r.fun("Bhavya",91,88,86,84,80);
		//r.fun(91,88,86,84,80,"Bhavya"); ---> wrong way to pass parameters
	}
}