import java.awt.*;
import java.applet.*;
/*<applet code=Login height=300 width=300> </applet>*/
public class Login extends Applet
{
    TextField nm,pw;
    Button b1,b2;
    public void init()
    {
	setLayout(null);
        Label n1=new Label("Name : ");
        Label p1=new Label("Password : ");
        nm=new TextField(20);
        pw=new TextField(20);
        b1=new Button("Login");
	b2=new Button("Signup");
        add(n1);
        add(nm);
        add(p1);
        add(pw);
        add(b1);
	add(b2);
        n1.setBounds(20,15,70,10);
        p1.setBounds(20,40,70,10);
        nm.setBounds(90,10,120,20);
        pw.setBounds(90,35,120,20);
        b1.setBounds(20,80,70,20);
        b2.setBounds(120,80,70,20);
    }
    public void paint(Graphics g)
    {
        repaint();
    }
}