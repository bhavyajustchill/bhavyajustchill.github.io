class DiamondPattern
{
	public static void main(String[] args)
	{
		int k=1,x;
		for(int i=0;i<5;i++)
		{
			for(int j=5;j>i;j--)
			{
				System.out.print("   ");	
			}
			System.out.print(" * ");
			if(i>0)
			{
				for(int l=1; l<=k; k++)
				{
					System.out.print("   ");
				}
				k+=2;
				System.out.print(" * ");
			}
			System.out.println();
		}
		k-=4;
		for(x=0;x<5;x++)
		{
			for(int y=0;y<x;y++)
			{
				System.out.print("   ");
			}
			System.out.print(" * ");
		}
		for(int z=1;z<=k;z++)
		{
			System.out.print("   ");
		}
		k-=2;
		if(x!=4)
		{
			System.out.print(" * ");
		}
		System.out.println();
	}
}