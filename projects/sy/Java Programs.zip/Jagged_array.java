class Jagged_array
{
	public static void main(String[] args)
	{
		int[][] x={{1,2,3,4,5},{6,7}}; //Jagged Array

		/*
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println(x[i][j]);
			}
		} This will print 1 2 6 7 because it doesnt get the length
		  If we use j<5 then it will print with an exception
		*/

		for(int k=0;k<x.length;k++) //correct way to print jagged arrays
		{
			for(int l=0;l<x[k].length;l++)
			{
				System.out.println(x[k][l]);
			}
		}
	}
}