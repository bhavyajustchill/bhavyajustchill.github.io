package mathpack;
import mathpack.MathDemo;
import java.util.Scanner;
public class MathTest
{
	public static void main(String[] args)
	{
		int a,b;
		Scanner sc = new Scanner(System.in);
		MathDemo m1 = new MathDemo();
		System.out.println("Enter 2 Integers");
		a=sc.nextInt();
		b=sc.nextInt();
		m1.add(a,b);
		m1.sub(a,b);
	}
}