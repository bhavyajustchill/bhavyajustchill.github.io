class Percentage3
{
   public static void main(String args[])
   {
 
	double total=0; 
	try
	{
		for(int i=1;i<3;i++)
		{
           		total=total+Integer.parseInt(args[i]);	
 		}
  		System.out.print("Percentage : "+total/3);
	}
	catch(Exception e1)
	{
		System.out.println("NumberFormatException : For a char entered instead of an int");
	}
   }
 
}