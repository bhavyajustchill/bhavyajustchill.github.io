abstract class Vehicle
{
	abstract void start();
}
class Bike extends Vehicle
{
	void start()
	{
		System.out.println("Kickstart!");
	}
}
class Car extends Vehicle
{
	void start()
	{
		System.out.println("Self Start!");
	}
}
class VehicleAbs
{
	public static void main(String[] args)
	{
		Car c1 = new Car();
		Bike b1 = new Bike();
		b1.start();
		c1.start();
	}
}