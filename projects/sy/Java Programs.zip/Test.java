package com.tcs.bank.loan;
public class Test
{
	public Test()
	{
		System.out.println("Hello");
	}
}