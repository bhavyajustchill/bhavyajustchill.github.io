class StaticKeyword
{
	static int i=0; // shared across all objects
	void count()
	{
		i++;
	}
	void display()
	{
		System.out.println(i);
	}
	public static void main(String[] args)
	{
		StaticKeyword s1 = new StaticKeyword();
		StaticKeyword s2 = new StaticKeyword();
		StaticKeyword s3 = new StaticKeyword();
		s1.count();// i=1
		s2.count();// i=2
		s1.display();
		s3.count();// i=3
		s2.display();
		s3.display();
	}
}