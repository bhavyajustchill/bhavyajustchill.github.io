class Sum
{
	int a,b,ans;
	Sum(int x,int y)
	{
		a=x;
		b=y;
	}
	void calc()
	{
		ans=a+b;
	}
	void display()
	{
		System.out.println(ans);
	}
	public static void main(String[] args)
	{
		Sum s1 = new Sum(12,8); // constructor dynamically allocated
		s1.calc();
		s1.display();
	}
}