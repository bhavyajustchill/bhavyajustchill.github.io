class ThisPointer
{
	int a,b;
	void setData(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
	void display()
	{
		System.out.println("A : "+a);
		System.out.println("B : "+b);
	}
	public static void main(String[] args)
	{
		ThisPointer t = new ThisPointer();
		t.setData(5,6);
		t.display();
	}
}