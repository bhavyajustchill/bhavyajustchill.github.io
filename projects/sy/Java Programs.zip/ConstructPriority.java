class A
{
	A()
	{
		System.out.println("Class A Default Constructor");
	}
	A(int i)
	{
		System.out.println("Class A Parameterized Constructor");
	}
}
class B extends A
{
	B()
	{
		super();
		/* a method which is called by default so it can call Parent class constructor first */
		System.out.println("Class B Default Constructor");
	}
	B(int i)
	{
		System.out.println("Class B Parameterized Constructor");
	}
}
class C extends A
{
	C()
	{
		System.out.println("Class C Default Constructor");
	}
	C(int i)
	{
		super(i);
		/* Passing Argument in Super class by super() method */
		System.out.println("Class C Parameterized Constructor");
	}
}
class ConstructPriority
{
	public static void main(String[] args)
	{
		B b1 = new B(); // Default Constructor Call
		B b2 = new B(1); // Parameterized Constructor Call
		C c1 = new C(1); // Parameterized Construcotr Overload
	}
}