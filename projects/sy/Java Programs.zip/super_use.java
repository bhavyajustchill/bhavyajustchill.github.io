class A
{
	int i;
	int j;
	A()
	{
		i=1;
		j=2;
	}
}
class B extends A
{
	int a;
	B()
	{
	}
}
class super_use
{
	public static void main(String args[])
	{
		B obj = new B();
		System.out.println(obj.i+" "+obj.j);
	}
}