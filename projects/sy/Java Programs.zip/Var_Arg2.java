class Var_Arg2
{
	
	void test(int... a)
	{
		int total=0;
		for(int a1:a)
		{
			total=total+a1;
			
		}
		System.out.print(total);
	}
	public static void main(String[] args)
	{
		Var_Arg2 v = new Var_Arg2();
		v.test(10,20,30);
		
	}

}