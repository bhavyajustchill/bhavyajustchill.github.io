public class A
{
	public static void main(String[] args)
	{
		System.out.println("Class A");
	}
}
public class B
{
	public static void main(String[] args)
	{
		System.out.println("Class B");
	}
}
class C
{
	public static void main(String[] args)
	{
		System.out.println("Class C");
	}
}