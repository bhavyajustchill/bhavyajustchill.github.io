class Display
{
	synchronized public void wish(String name) // synchronized lets one thread complete its work before switching
	{
		for(int i=0;i<10;i++)
		{
			System.out.print("Good Morning ");
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
			}
			System.out.println(name);
		}
	}
}
class ThreadDemo extends Thread
{
	Display d1;
	String name;
	ThreadDemo(Display d1,String name)
	{
		this.d1=d1;
		this.name=name;
	}
	public void run()
	{
		d1.wish(name);
	}
}
class SyncDemo
{
	public static void main(String[] args)
	{
		Display d1 = new Display();
		ThreadDemo t1 = new ThreadDemo(d1,"Bhavya");		
		ThreadDemo t2 = new ThreadDemo(d1,"Manas");
		ThreadDemo t3 = new ThreadDemo(d1,"Smeet");
		t1.start();
		t2.start();
		t3.start();
	}
}